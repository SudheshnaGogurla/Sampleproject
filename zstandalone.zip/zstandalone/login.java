package main.zstandalone;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.Command;
import org.openqa.selenium.remote.CommandExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.Response;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.remote.codec.w3c.W3CHttpCommandCodec;
import org.openqa.selenium.remote.codec.w3c.W3CHttpResponseCodec;
import org.openqa.selenium.remote.http.JsonHttpCommandCodec;
import org.openqa.selenium.remote.http.JsonHttpResponseCodec;
import java.net.URLEncoder;

import static main.java.broadbean.po.CustomerConnectBroadBeanForm.Button.LOGIN_TO_BROADBEAN;
import static main.java.broadbean.po.CustomerConnectBroadBeanForm.Button.POST_TO_BROADBEAN;
import static main.java.customerconnect.handler.QuickLinksHandler.Type.JOB_LEADS;
import static main.java.customerconnect.po.xp.FasterPageAction.Type.NEW;
import static org.page.parq.runner.run.Parq.className;
import static org.page.parq.runner.run.Parq.compose;
import static org.page.parq.runner.run.Parq.css;
import static org.page.parq.runner.run.Parq.focus;
import static org.page.parq.runner.run.Parq.id;
import static org.page.parq.runner.run.Parq.linkText;
import static org.page.parq.runner.run.Parq.pause;
import static org.page.parq.runner.run.Parq.perform;
import static org.page.parq.runner.run.Parq.select;
import static org.page.parq.runner.run.Parq.text;
import static org.page.parq.runner.run.Parq.touch;
import static org.page.parq.runner.run.Parq.txt;
import static org.page.parq.runner.run.Parq.val;
import java.net.URLEncoder;

import java.io.IOException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import main.java.broadbean.po.AdvertForm;
import main.java.broadbean.po.BroadBean;
import main.java.broadbean.po.CustomerConnectBroadBeanForm;
import main.java.broadbean.po.JobAdvert;
import main.java.broadbean.po.Language;
import main.java.broadbean.po.ManageAdverts;
import main.java.broadbean.po.Responses;
import main.java.customerconnect.handler.QuickLinksHandler;
import main.java.customerconnect.po.*;
import main.java.customerconnect.po.xp.EmailCVToClient;
import main.java.customerconnect.po.xp.EntityHeaderSection;
import main.java.customerconnect.po.xp.FasterPageAction;
import main.java.customerconnect.po.xp.FasterShortlist;
import main.java.customerconnect.po.xp.NewJobBoardApplication;
import main.java.goldenqa.po.ApplicantDetails;
import main.java.goldenqa.po.BroadBeanSubmission;
import main.java.goldenqa.po.GeneralSubmission;
import main.java.test.CCQATest.CCUILibrary;
import main.java.test.EnvConfig.BaseClass;
import main.java.test.EnvConfig.VMArgs;
import main.java.test.MRP.TempPlacement.UpdateActions;
import main.java.test.journeys.FasterPageTable;
import main.java.users.Country;
import main.zstandalone.LocalExecutor;

import org.page.parq.runner.run.Parq;
import org.page.parq.runner.run.ParqException;
import org.page.parq.runner.support.Index;

//-Dserver=UAT -Dcountry=FR -Dpagediv=PP-Dregion=CO
//https://testfile--uat.lightning.force.com
//uk.fe.auto.qatest@michaelpage.com.uat London2021@@1
//fr.fe.auto.qatest@michaelpage.com.uat Paris2021@@@@
//fr.fin.auto.qatest@michaelpage.com.uat Paris2021!!!
//fr.lc.auto.qatest@page.com.uat
// uk.fe.auto.qatest@michaelpage.com.uat London2021@@@@@
//https://testfile--preprod.my.salesforce.com/
//uk.fe.auto.qatest@michaelpage.com.ppe
//London2022@@
//co.fe.auto.qatest@michaelpage.com.uat co.fin.auto.qatest@michaelpage.com.uat Bogota2022@@
//int total_frames1 = Parq.getDriver().findElements(By.tagName("iframe")).size();
//System.out.println("Total frames in application is "+ total_frames1);
//focus(id("username")).compose("fr.fe.auto.qatest@michaelpage.com.uat");  // VM UPDATE
//focus(id("password")).compose("Paris2021@@@");
//focus(LOGIN).touch();  
//focus(css("title", "Edit Candidate Company Name"));
//focus(text("Candidate Company Name"));
//descend(css("data-value", selection.getValue()));
//descend(text(field));
//Browser.scrollTo();focus(className("resultitems"));
//focus(name("CAP_CC_Expected_Fill_Month__c"));
//traverse();
//descend(tag(LIST_ITEM, 1 ));
//reverse();
//descend(tag(LIST_ITEM, 1 ));
//Browser.scrollTo(CV_MANAGER);
//pause(2);
//Browser.pageUp();
//Page.sleep(3);
//try{
//  focus(partialText("Show All"));
//	pause(3);
//	touch();
//}catch (Exception e){
//  e.printStackTrace();
//}
//QuickLink.select(CANDIDATE_COMPLIANCE_CHECKLIST);
//Menu.select(Menu.Type.JOBS);
//Page.sleep(5);
//Search.searchAndSelectFromList(references.getJob());
//QuickLink.navigate(QuickLink.Type.JOB_SPLITS);
//focus(text("Email")); css("for", "edit-mp-privacy-policy");
//Browser.scrollTo();focus(LOCATION_HINT).collect(Html.LIST_ITEM).choose(Index.ListIndex.FIRST).touch();
//select((txt("25 - 30K")));compose(Keys.TAB);  focus(linkText( linkText ));

public class login {
      private static Country nationality;
      private static  Country workCountry;
      private static  Country residenceCountry;      
      public static Country country = Country.getCountryFromCode(VMArgs.getCountry()); 
      private static final BroadBeanSubmission broadBeanSubmission = new BroadBeanSubmission();
     public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException, IOException {
                                               
         GeneralSubmission generalSubmission = new GeneralSubmission();
         String CVPATH_FR_DOC = "CV\\CVFrench.docx";
         String CVPATH_FR_PDF = "CV\\CVFrench.pdf";
         ApplicantDetails applicantDetailsEnglishDoc = null;
         ApplicantDetails applicantDetailsCountrySpecificDoc = null;
         ApplicantDetails applicantDetailsCountrySpecificPDF = null;
                
         applicantDetailsCountrySpecificDoc = ApplicantDetails.createCandidate(CVPATH_FR_DOC, country);
         pause(3);
         applicantDetailsCountrySpecificPDF = ApplicantDetails.createCandidate(CVPATH_FR_PDF, country);
        
         //start with browser one
                    System.setProperty("webdriver.chrome.driver", "C:\\Automation\\drivers\\chromedriver\\chromedriver.exe");
                    ChromeDriver driverOne = new ChromeDriver();
                    driverOne.manage().window().maximize();
                    // setup: get information to initialize driver two
                    String sessionId = driverOne.getSessionId().toString();
                    URL addressOfRemoteServer = getEndpoint(driverOne);
                    Capabilities desiredCapabilities = driverOne.getCapabilities();
                    CommandExecutor commandExecutor = new LocalExecutor(sessionId, addressOfRemoteServer, desiredCapabilities);
                    System.out.println(sessionId);
                    System.out.println(desiredCapabilities);
                    URL url = ((HttpCommandExecutor) commandExecutor).getAddressOfRemoteServer();
                    System.out.println(url);
                    SessionId session_id = new SessionId(sessionId);                                
                    RemoteWebDriver driver = createDriverFromSession(session_id, url);
                    //driver.get("https://3719513-testfile.app.testfile.com/pages/customerlogin.jsp?c=3719513_testfile&whence=");
                    //driver.get("https://testfile--uat.lightning.force.com");
                    //driver.get("https://testfile--sitest.sandbox.lightning.force.com/lightning/r/TR1__Closing_Report__c/a0S3M000001wPmPUAU/view");
                    //driver.get("https://3719513-sb2.app.testfile.com");
                    //driver.get("https://testfile--sit.sandbox.lightning.force.com/lightning/r/TR1__Closing_Report__c/a0S3L0000001dAdUAI/view"); 
                    driver.get("https://testfile--preprod.sandbox.lightning.force.com/lightning/r/TR1__Closing_Report__c/a0S3M000002zCnkUAE/view");
                    
                    //driver.get("https://www.google.co.uk/");
                    //driver.get("https://testfile--preprod.sandbox.my.salesforce.com/");
                    //EntityHeaderSection.verifyCandidateStage("QA AUTO UK FE MAIN");
                    //fr.fin.auto.qatest@michaelpage.com.ppe London2022@@@
                    //R2RAPAC_01@autotest.com   Welcome2019
                    //S10034880
                    
                    //driver.get("https://3719513-testfile.app.testfile.com/app/accounting/transactions/vendbill.nl?whence=&cf=50&entity=2068979&nexus=50&custpage_4601_appliesto=&subsidiary=121&manual_reload=T");
                          

    }

    private static void show() {
		// TODO Auto-generated method stub
		
	}

	private static URL getEndpoint(WebDriver driver) throws NoSuchFieldException, IllegalAccessException {
        // get RemoteWebDriver type
        Class remoteWebDriver = getRemoteWebDriver(driver.getClass());

        // get this instance executor > get this instance internalExecutor
        Field executorField = remoteWebDriver.getDeclaredField("executor");
        executorField.setAccessible(true);
        CommandExecutor executor = (CommandExecutor) executorField.get(driver);

        // get URL
        Field endpointField = getCommandExecutor(executor.getClass()).getDeclaredField("remoteServer");
        endpointField.setAccessible(true);

        // result
        return (URL) endpointField.get(executor);
    }

    private static Class getRemoteWebDriver(Class type) {
        // if not a remote web driver, return the type used for the call
        if (!RemoteWebDriver.class.isAssignableFrom(type)) {
            return type;
        }

        // iterate until gets the RemoteWebDriver type
        while (type != RemoteWebDriver.class) {
            type = type.getSuperclass();
        }

        // gets RemoteWebDriver to use for extracting internal information
        return type;
    }

    private static Class getCommandExecutor(Class type) {
        // if not a remote web driver, return the type used for the call
        if (!HttpCommandExecutor.class.isAssignableFrom(type)) {
            return type;
        }

        // iterate until gets the RemoteWebDriver type
        while (type != HttpCommandExecutor.class) {
            type = type.getSuperclass();
        }

        // gets RemoteWebDriver to use for extracting internal information
        return type;
    }
    public static RemoteWebDriver createDriverFromSession(final SessionId sessionId, URL command_executor){
        CommandExecutor executor = new HttpCommandExecutor(command_executor) {

            @Override
            public Response execute(Command command) throws IOException {
                Response response = null;
                if (command.getName() == "newSession") {
                    response = new Response();
                    response.setSessionId(sessionId.toString());
                    response.setStatus(0);
                    response.setValue(Collections.<String, String>emptyMap());

                    try {
                        Field commandCodec = null;
                        commandCodec = this.getClass().getSuperclass().getDeclaredField("commandCodec");
                        commandCodec.setAccessible(true);
                        commandCodec.set(this, new W3CHttpCommandCodec());

                        Field responseCodec = null;
                        responseCodec = this.getClass().getSuperclass().getDeclaredField("responseCodec");
                        responseCodec.setAccessible(true);
                        responseCodec.set(this, new W3CHttpResponseCodec());
                    } catch (NoSuchFieldException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                } else {
                    response = super.execute(command);
                }
                return response;
            }
        };

        return new RemoteWebDriver(executor, new DesiredCapabilities());
    }
}

