﻿package main.zstandalone;


import static org.page.parq.runner.run.Parq.*;
import org.page.parq.runner.run.ParqException;
import org.page.parq.runner.search.Searcher;
import org.page.parq.runner.support.Index;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Command;
import org.openqa.selenium.remote.CommandExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.remote.Response;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.remote.codec.w3c.W3CHttpCommandCodec;
import org.openqa.selenium.remote.codec.w3c.W3CHttpResponseCodec;
import org.openqa.selenium.remote.http.JsonHttpCommandCodec;
import org.openqa.selenium.remote.http.JsonHttpResponseCodec;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.text.SimpleDateFormat;

import static main.java.customerconnect.po.Tabs.Type.*;
import main.java.mongo.ccobjects.Environment;
import main.java.netsuite.handler.GenericSearchHandler;
import static org.page.parq.runner.support.Index.ListIndex.FIRST;
import static org.page.parq.runner.support.Index.ListIndex.SECOND;
import static main.java.mongo.services.MongoServices.environmentService;
import static main.java.mongo.services.MongoServices.userService;
import static org.page.parq.runner.support.Colours.RESET;
import static main.java.test.MRP.TempPlacement.UpdateActions.Date.*;
import static org.page.parq.runner.support.Html.Tag.*;
import static java.lang.String.format;
import static main.java.broadbean.po.CustomerConnectBroadBeanForm.Button.LOGIN_TO_BROADBEAN;
import static main.java.broadbean.po.CustomerConnectBroadBeanForm.Button.POST_TO_BROADBEAN;
import static main.java.customerconnect.handler.QuickLinksHandler.Type.JOB_LEADS;
import static main.java.customerconnect.po.Contact.Field.BILLING_CONTACT;
import static main.java.customerconnect.po.ContactDetail.Field.ALERT_DESCRIPTION;
import static main.java.customerconnect.po.ModalSLDS.Action.SAVE;
import static main.java.customerconnect.po.NewContact.SALUTATION;
import static main.java.customerconnect.po.NewJob.Type.PERMANENT;
import static main.java.customerconnect.po.PageAction.Type.APPROVE;
import static main.java.customerconnect.po.PageAction.Type.CANCEL;
import static main.java.customerconnect.po.ModalSLDS.Action.CANCEL;
import static main.java.customerconnect.po.Toast.Type.CALL_LIST_ALREADY_EXISTS;
import static main.java.customerconnect.po.Toast.Type.LONGLIST_SAVED;
import static main.java.customerconnect.po.Toast.Type.COMPLIANCE_COMPLIANT_STATUS;
import static main.java.customerconnect.po.Toast.Type.TASK;
import static main.java.customerconnect.po.xp.FasterPageAction.Type.ADD_TO_SHORTLIST;
import static main.java.customerconnect.po.xp.FasterPageAction.Type.NEW;
import static main.java.test.MRP.TempPlacement.Rate.Field.RATE_TYPE;
import static main.java.test.MRP.TempPlacement.Rate.RateType.STANDARD_RATE;
import static main.java.test.Utilities.GeneralCommonFunctions.getResourcePath;
import static main.java.test.journeys.JobSplit.Consultant.CONSULTANT_DOM_FE1;
import static main.java.test.journeys.JobSplit.Consultant.CONSULTANT_FE_INT;
import static main.java.test.journeys.JobSplit.Field.REFERRAL_TYPE;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;
import main.java.users.Country;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.swing.text.html.HTML;

import main.java.broadbean.po.AdvertForm;
import main.java.broadbean.po.BroadBean;
import main.java.broadbean.po.CustomerConnectBroadBeanForm;
import main.java.broadbean.po.JobAdvert;
import main.java.broadbean.po.Language;
import main.java.broadbean.po.ManageAdverts;
import main.java.broadbean.po.Responses;
import main.java.customerconnect.handler.CandidateStatusHandler;
import main.java.customerconnect.handler.JavascriptExecutionHandler;
import main.java.customerconnect.handler.MouseHoverAndClickHandler;
import main.java.customerconnect.handler.QuickLinksHandler;
import main.java.customerconnect.handler.ScrollIntoViewHandler;
import main.java.customerconnect.po.*;
import main.java.customerconnect.po.NewAccount.Label;
import main.java.customerconnect.po.xp.CallListDetails;
import main.java.customerconnect.po.xp.CandidateDetails;
import main.java.customerconnect.po.xp.Dialog;
import main.java.customerconnect.po.xp.EmailCVToClient;
import main.java.customerconnect.po.xp.EntityHeaderSection;
import main.java.customerconnect.po.xp.FasterForm;
import main.java.customerconnect.po.xp.FasterPageAction;
import main.java.customerconnect.po.xp.FasterQuickAdd;
import main.java.customerconnect.po.xp.FasterShortlist;
import main.java.customerconnect.po.xp.FasterTabs;
import main.java.customerconnect.po.xp.ImprovisedToast;
import main.java.customerconnect.po.xp.NewJobBoardApplication;
import main.java.data.customerconnect.api.json.AccountField;
import main.java.data.customerconnect.api.json.Rate;
import main.java.data.customerconnect.api.lib.APILibrary;
import main.java.data.customerconnect.api.lib.EntityJSON;
import main.java.goldenqa.po.ApplicantDetails;
import main.java.goldenqa.po.BroadBeanSubmission;
import main.java.goldenqa.po.GeneralSubmission;
import main.java.test.Archive.tests.CCLibrary;
import main.java.test.CCQATest.CCUILibrary;
import main.java.test.EnvConfig.BaseClass;
import main.java.test.EnvConfig.VMArgs;
//import main.java.test.MRP.DataSharing.DS_Accounts;
import main.java.test.MRP.TempPlacement.TPLibrary;
import main.java.test.MRP.TempPlacement.UpdateActions;
import main.java.test.Utilities.DateUtils;
import main.java.test.Utilities.GeneralCommonFunctions;
import main.java.test.journeys.FasterPageTable;
import main.java.test.journeys.JobSplit;
import main.java.users.CCUser;
import main.java.users.Country;
import main.zstandalone.LocalExecutor;
import static org.page.parq.runner.run.Parq.*;
import org.page.parq.runner.run.Parq;
import org.page.parq.runner.run.ParqException;
import org.page.parq.runner.search.Locator;
import org.page.parq.runner.search.Searcher;
import org.page.parq.runner.support.ElementData;
import org.page.parq.runner.support.Html;
import org.page.parq.runner.support.HtmlAttribute;
import org.page.parq.runner.support.Index;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mongodb.assertions.Assertions;
import com.mongodb.util.JSON;

import groovyjarjarantlr.StringUtils;
//import io.opentracing.propagation.Format;

import static org.page.parq.runner.support.Index.ListReference.TAIL;
import static org.page.parq.runner.support.Logger.logWarn;
import static main.java.customerconnect.handler.QuickLinksHandler.Type.*;
import static main.java.customerconnect.po.Toast.Type.DUPLICATE_RECORD;
import static main.java.customerconnect.po.Form.ADD_TO_CALLLIST;
import static main.java.customerconnect.po.Form.ADD_TO_LONGLISTS;
import static main.java.customerconnect.po.Form.ADD_TO_EMAIL;
import static main.java.customerconnect.po.Form.ADD_TO_PROJECT;
import static main.java.customerconnect.po.Form.ADD_TO_SHORTLIST;



public class xpathextract {
	 protected static final Table table = new Table();
	 protected static final main.java.customerconnect.po.Tabs tabs = new main.java.customerconnect.po.Tabs();
	 public final static Locator ERRORS_LIST =  className("errorsList");
	 protected static final ImprovisedToast improvisedToast = new ImprovisedToast();
	 protected static final Modal modal = new Modal();	
	    public static Country country = Country.getCountryFromCode(VMArgs.getCountry());
	    Environment environment = environmentService.get( VMArgs.getServer());
	 private static AccountField accountField;
	  protected static final FasterPageAction fasterPageAction = new FasterPageAction();
	    private static final String ACTIVITY = "Activity";
	    private static final String CHATTER = "Chatter";
	    private static final String CHNAGELOG = "Change Log";
	    private static final String APPROVALHISTORY = "ccapp";
	  
	
     public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException, IOException {
                
         URL url = new URL("http://localhost:7562");      
         SessionId session_id = new SessionId("ebfbd274967d5abffe2bafe7b6cc3f0e");                                 
         RemoteWebDriver driver2 = createDriverFromSession(session_id, url);
         Parq.setDriver(driver2);                    
         String title=Parq.getDriver().getTitle();
         System.out.println("title is "+title);
         APILibrary apiLib = new APILibrary();
         References references = apiLib.ref;
         
        //String salesForceAccountID ="0013L00000clnj9QAA"; //Legal Entity
        
        String salesForceAccountID ="0013L00000dfjRDQAY"; //Legal Entity
        
        //String salesForceAccountID ="0013L00000dfhARQAY"; //Sales Entity        
        references.setAccountSFId(salesForceAccountID);
        
        
        String ninumberupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FINANCE, country,references.getAccountSFId(),"ninumberupdate", "test");
        System.out.println("ninumberupdate is "+ninumberupdate);          
        Assert.assertEquals(ninumberupdate.length(),0);
        
        String legalentityupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FINANCE, country,references.getAccountSFId(),"legalentityupdate", "test");
        System.out.println("legalentityupdate is "+legalentityupdate);          
        Assert.assertEquals(ninumberupdate.length(),0);
        
        String billingcountryupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FINANCE, country,references.getAccountSFId(),"billingcountryupdate", "test");
        System.out.println("billingcountryupdate is "+billingcountryupdate);          
        Assert.assertEquals(ninumberupdate.length(),0);
        
        String DnBConnectDUNSupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FINANCE, country,references.getAccountSFId(),"DnBConnectDUNSupdate", "test");
 	    System.out.println("DnBConnectDUNSupdate is "+DnBConnectDUNSupdate);
 	    assertTrue(DnBConnectDUNSupdate.contains("Unable to create/update fields: CAP_CC_DnB_Connect_DUNS__c"));
 	    
 	    String dnBcompanyprofileupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FINANCE, country,references.getAccountSFId(),"dnBcompanyprofileupdate", "test");
 	    System.out.println("dnBcompanyprofileupdate is "+dnBcompanyprofileupdate);
 	    assertTrue(dnBcompanyprofileupdate.contains("Unable to create/update fields: DNBConnect__D_B_Connect_Company_Profile__c"));
        
        
        
        
//        //FE can edit ninumberupdate
//        String ninumberupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FEE_EARNER, country,references.getAccountSFId(),"ninumberupdate", "test");
//        System.out.println("ninumberupdate is "+ninumberupdate.length());
//        Assert.assertEquals(ninumberupdate.length(),0);
//        
//        //FE can edit legalentityupdate
//        String legalentityupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FEE_EARNER, country,references.getAccountSFId(),"legalentityupdate", "test");
//        System.out.println("legalentityupdate is "+legalentityupdate);          
//        Assert.assertEquals(legalentityupdate.length(),0);
        
        
        
        //assertTrue(ninumberupdate.contains("You are not allowed to change information on legal entity account"));
 	    
 	     
//        String DnBConnectDUNSupdate = apiLib.updateFieldOnAccountPage(references,CCUser.UserType.FEE_EARNER, country,references.getAccountSFId(),"DnBConnectDUNSupdate", "test");
// 	    System.out.println("DnBConnectDUNSupdate is "+DnBConnectDUNSupdate);
// 	    assertTrue(DnBConnectDUNSupdate.contains("Unable to create/update fields: CAP_CC_DnB_Connect_DUNS__c"));

         
         
      
        //focus(text("This record looks like an existing record. Make sure to check any potential duplicate records before saving."));
        
        
       
//     	List lstElmnt= Parq.getDriver().findElements(By.xpath("(//*[(text()='This record looks like an existing record. Make sure to check any potential duplicate records before saving.' )])"));  
//     	System.out.println("Element size is " +lstElmnt.size());
//  		if(lstElmnt.size()>0){
//  			Modal.selectModalButton(Modal.Actions.SAVE);  		 
//  		}
  		
         
	     
//         String actDUNSNumber = FormData.fetchLabelFormValue("D&B Connect DUNS");
//  		 System.out.println("actDUNSNumber is "+ actDUNSNumber);
//  		 Assert.assertEquals(actDUNSNumber, "");
         //FormData.fetchLabelFormValue("D&B Connect DUNS");
         
//     	focus(text("D&B Connect Company Profile"));
//	   	ascend();
//	   	ascend();
//	   	descend(tag("slot"));
//	   	String DnBConectCompanyProfile = fetch(ElementData.TEXT);
//	   	System.out.println("DnBConectCompanyProfile is " + DnBConectCompanyProfile);
		 
//         focus(text("Account Record Type"));
//         ascend();
//         traverse();
//         descend(tag("span")); 
//         descend(tag("span")); 	         
//         String actlegalentity = fetch(ElementData.TEXT);
//         System.out.println("actRecordtype is "+ actlegalentity);
//         String actDnBConnecCompanyProfile = FormData.fetchDnBConectCompanyProfile("D&B Connect Company Profile");
//         System.out.println("actDnBConnecCompanyProfile is "+ actDnBConnecCompanyProfile);         
//     	 Assert.assertEquals(actDnBConnecCompanyProfile, "MITCHELLS & BUTLERS RETAIL LIMITED" );     	 
//     	 String expDUNSNumber = FormData.fetchLabelFormValue("D&B Connect DUNS");
//		 System.out.println("expDUNSNumber is "+ expDUNSNumber);
//		 Assert.assertEquals(expDUNSNumber, "293411179");		
//		 String actregistrationNumberone = FormData.fetchLabelFormValue("National Identification Number 1");
//		 System.out.println("actregistrationNumberone is "+ actregistrationNumberone); 
//		 Assert.assertEquals(actregistrationNumberone, "");
//		 String actregistrationNumbertwo = FormData.fetchLabelFormValue("National Identification Number 2");
//		 System.out.println("actregistrationNumbertwo is "+ actregistrationNumbertwo); 
//		 Assert.assertEquals(actregistrationNumbertwo, "00024542");
//		 String actegistrationNumberthree = FormData.fetchLabelFormValue("National Identification Number 3");
//		 System.out.println("actegistrationNumberthree is "+ actegistrationNumberthree);
//		 Assert.assertEquals(actegistrationNumberthree, "");
//		 String actregistrationNumberfour = FormData.fetchLabelFormValue("National Identification Number 4");
//		 System.out.println("actregistrationNumberfour is "+ actregistrationNumberfour);
//		 Assert.assertEquals(actregistrationNumberfour, "");
     	
     	
     	
         
//        focus(text("D&B Connect Company Profile"));
//     	ascend();
//     	ascend();
//     	descend(tag("a"));
//     	descend(tag("span"));
//     	String actcancellationreason = fetch(ElementData.TEXT);
//     	System.out.println("actcancellationreason is "+actcancellationreason);
//     	String dunsURL=Parq.getDriver().findElement(By.xpath("//*[(text()='D&B Connect Company Profile' )]/./.././..//a")).getAttribute(("href"));
//     	System.out.println("dunsURL is "+ dunsURL);
//     	Parq.go("https://pagegroup--sit.sandbox.lightning.force.com/lightning/r/DNBConnect__D_B_Connect_Company_Profile__c/aAK3L0000004DaoWAE/view");
         
//         String CompanyProfilename = FormData.fetchLabelFormValue("D&B Connect Company Profile");
//         System.out.println("CompanyProfilename is "+ CompanyProfilename);         
//         String DUNSNumber = FormData.fetchLabelFormValue("D-U-N-S Number");
//         System.out.println("DUNSNumber is "+ DUNSNumber);
//         String registrationNumberone = FormData.fetchLabelFormValue("Registration Number 1");
//         System.out.println("registrationNumberone is "+ registrationNumberone); 
//         String registrationNumbertwo = FormData.fetchLabelFormValue("Registration Number 2");
//         System.out.println("registrationNumbertwo is "+ registrationNumbertwo);    
//         String registrationNumberthree = FormData.fetchLabelFormValue("Registration Number 3");
//         System.out.println("registrationNumberthree is "+ registrationNumberthree); 
//         String registrationNumberfour = FormData.fetchLabelFormValue("Registration Number 4");
//         System.out.println("registrationNumberfour is "+ registrationNumberfour);
         
         
//        focus(text("D&B Connect Company Profile"));
//      	ascend();
//      	ascend();
//      	descend(tag("a"));
//      	descend(tag("span"));
//      	String actcancellationreason = fetch(ElementData.TEXT);
//      	System.out.println("actcancellationreason is "+actcancellationreason); 
         
         
//         focus(text("Remove Out of Business Records"));
//         ascend();
//         ascend();
//         ascend();
//         descend(tag("input")).touchJS();
//         ascend();         
//  		 String currentRatevalue = fetch(ElementData.TEXT);
//  		 String[] matchStatusSplit = currentRatevalue.split("Match status :");	
//  		 String accountMatchStatus= matchStatusSplit[1].trim();
//  		 System.out.println("accountMatchStatusis " + accountMatchStatus);
    
  		 
  		 
  		//focus(partialText("Match status"));
         
//         focus(Modal.CONTAINER);
// 		focus(text("Account Name"));
// 		ascend(tag("div"));
// 		descend(tag("input"));
// 		clear();
// 		
// 		compose("test");
//         System.out.println("title is "+title);
//         Modal.inputBusinessName(Label.BUSINESS_NAME,"retail");
//         focus(Modal.SEARCH); 
//         touch();
         //Modal.selectCheckBox(Label.DnBCONNECTEXCLUDEMATCH);
//         focus(tagContains(LABEL, "Country"));
// 		traverse();
// 		descend(tag("input"));
// 		compose("United Kingdom");
// 		pause(5);
// 		Browser.pageDown();
// 		pause(5);
// 		focus(partialText("United Kingdom")).touch();
// 		Page.handleSpinner();
// 		Browser.pageDown();
// 		pause(5);
// 		Modal.formSelectValue(Label.COUNTRY,country);
//         pause(3);
//         focus(Modal.SEARCH);
// 		touch();
// 		Page.handleSpinner();
// 		focus(css("id", "createButton")).touchJS();
         
         
         //Model.dropdown_form(NewJobLead.Field.JOB_TYPE, NewJobLead.JobType.PERMANENT.getValue());
         
         //Model.dropdown_form(NewJobLead.Field.LEAD_TYPE, NewJobLead.LeadType.AD_CHASE.getValue());
         
//        focus(text("Lead Type")); // to <span> in modals
// 		ascend();
// 		ascend();
// 		descend(Html.ANCHOR);
// 		pause(5);
// 		touch();
// 		pause(3);
// 		focus(css("title", "Ad Chase"));
// 		pause(5);
// 		touch();
         
//         focus(css("value","New"));
//         ascend(tag("span"));
//         descend(tag("input")).touchJS();
//         focus(tagContains(LABEL, "Name"));
//         ascend();
//         ascend();
//         descend(tag("input"));
//         compose("this is test");         
//         focus(text("Create and add"));
//         touch();
//         Toast.acknowledgeCreation();
         
//         origin();
//         collect(className("slds-input slds-combobox__input has-custom-height slds-combobox__input-value"));
//         choose(Index.ListIndex.FIRST);
//         touch();
//         Page.handleSpinner();
//         pause(3);            
//         compose("Auto CallList hsmrim");
//         pause(2);
//         Page.handleSpinner();
//         origin();
//         collect(className("slds-listbox__option-text slds-listbox__option-text_entity"));   
//         choose(TAIL);
//         touchJS();
         
  	
  
         
         
//         ascend();
//         ascend();
//         descend(tag("input"));
         
         
//         //frame();
//         focus(text("Create new"));
////         ascend();
////         ascend();
////         ascend();
////         ascend();
////         ascend();
////         //traverse();
////         descend(tag("input"));
//         ascend(tag("input")).touchJS();
         
         
         //focus(text("Accept all")).touchJS();
         
//           focus(name("q"));
//           touch();
//           compose("this is test");
           
           //Parq.getDriver().findElement(By.xpath("//*[(text()='Accept all' )]")).sendKeys("test");
           //Parq.getDriver().findElement(By.xpath("//*[@name='q']")).click();
           //Parq.getDriver().findElement(By.xpath("//*[@name='q']")).sendKeys("T");
         
         //Parq.getDriver().findElement(By.xpath("//*[(text()='Accept all' )]")).click();
         
//         Modal.load();
//         pause(3);
//         Modal.sldsInputVertical("Cancellation Notes", "Notes"); 
//         pause(5);
//         ModalSLDS.selectDropDown("Cancellation Reason", "Unavoidable - Amount renegotiated"); 
//         pause(5);
//         ModalSLDS.selectDropDown("Change Owner", "Billing"); 
         
//         
//         focus(text("Master SO"));
//         ascend();
//         traverse();
//         descend(tag("a"));
//         descend(tag("span"));
//         contains(salesOrder.getRef());
         
         
//         focus(tagContains(SPAN, "Placement Cancel Reason"));   
//         ascend(tag("div"));
//         traverse();
//         collect(tag("option"));
//         choose(txt("Admin Error"));
//         Page.sleep(2);
//         touch();
         
         
//         focus(text("Contract Extension"));
//         ascend(tag("flowruntime-flow"));
         //ascend(tag("div"));
         //traverse();
         //traverse();
    	 //ascend();
//         focus(text("End Date"));
//     	  ascend();
//     	  ascend();
//     	  ascend();
//     	  ascend();
//         
         //UpdateActions.updateEffectiveDate("nextMonth"); 
         
//         APILibrary apiLib = new APILibrary();
//         References references = apiLib.ref;
//         references = apiLib.updateFieldOnJob(references,CCUser.UserType.FEE_EARNER, country,"a1C3M000001ZjCTUA0","Number of Openings", "5");
         
         //FormData.validateJobDetails("Status", "Closed");
 		 //FormData.validateJobDetails("Closed Reason", "Filled");
         
//        focus(css("field-label","Closed Reason"));
// 	    descend(tag("lightning-formatted-text"));
// 		String currentRatevalue = fetch(ElementData.TEXT);
// 		System.out.println(currentRatevalue);
         
         
//  	   UpdateActions.validatePayandBillRate("Pay Rate", "GBP 150.00");
//  	   UpdateActions.validatePayandBillRate("Bill Rate", "GBP 150.00");
         
//         focus(css("data-label","Bill Rate"));
// 	    descend(tag("span"));
// 	    descend(tag("span"));
// 		String currentRatevalue = fetch(ElementData.TEXT);
// 		System.out.println("currentRatevalue " + currentRatevalue);
// 	   Assert.assertEquals(expRatevalue, currentRatevalue );
         
         
//        focus(css("data-label","Pay Rate"));
// 	    descend(tag("span"));
// 	    descend(tag("span"));
// 		String currentRatevalue = fetch(ElementData.TEXT);
// 		System.out.println("currentRatevalue " + currentRatevalue);
// 		Assert.assertEquals("GBP 150.00", currentRatevalue );
         
         
         //Tabs.select(RELATED);
         //Page.handleSpinner();
//         focus(css("data-label","Pay Rate"));
//         descend(tag("span"));
//         descend(tag("span"));
//		String currentRatevalue = fetch(ElementData.TEXT);
//		System.out.println("currentRatevalue " + currentRatevalue);
//		Assert.assertEquals("GBP 150.00", currentRatevalue );

		
//         ascend();
//         ascend();
         //ascend(tag("td"));
         //traverse();
//         traverse();
//         traverse();
         
         
         
         
//           focus(text("Effective From Date"));
//	       ascend();
//	       ascend();
//	       ascend();
//	       ascend();
//	       descend(tag("input"));
//     	   compose(DateUtils.getDate(DateUtils.When.TODAY, DateUtils.DateFormat.HYPHENATED ));
         
         
//         focus(text("New Pay Rate"));
//         ascend();
//         ascend();
//         ascend();
//         ascend();
//         descend(tag("input"));
//         clear();
//         compose("150");         
         
//         UpdateActions.select(UpdateActions.Action.RATES);
//         Page.sleep(2);
//         UpdateActions.next();
//         UpdateActions.select(UpdateActions.RatesChange.BILL_RATE_CHANGE);
//         Page.sleep(2);
//         UpdateActions.next();
//         //UpdateActions.updateNewPayRate("New Pay Rate","150");
//         UpdateActions.updateNewPayRate(NEW_BILL_RATE,"150");
//         Page.sleep(2);
//         //UpdateActions.updateEffectiveDate(EFFECTIVE_FROM_BILL_RATE);
//         UpdateActions.updateEffectiveDate(EFFECTIVE_FROM_DATE);
//         Page.sleep(2);
//         Page.sleep(2);
//	   	 UpdateActions.next();
//	   	 Page.sleep(2);
//	   	 UpdateActions.yes();
//	   	 Page.sleep(2);
//	   	 UpdateActions.next();
//	   	 Page.handleSpinner();  
   	     
         
         
         
//     	focus(Modal.CONTAINER);
//		descend(text("Pay Type")); // to <span> in modals
//		ascend();
//		ascend();
//		descend(Html.ANCHOR);
//		pause(5);
//		touch();
//		pause(3);
//		focus(css("title", "Payroll"));
//		pause(5);
//		touch();
         
         
         
//  		focus(Modal.CONTAINER);
//  		descend(text("Country"));
//  		ascend();
//  		ascend();
//  		descend(tag("input"));
//  		touch();
//  		ascend(tag("div"));
//  		ascend();
//  		ascend();
//  		ascend();
//  		ascend();
//  		collect(tag("lightning-base-combobox-item"));
//  		Parq.show();
//  		traverse();
//  		ascend();
  		//descend();
  		//descend(tag("div"));
//  		descend();
//  		collect(tag("lightning-base-combobox-item"));
//  		ascend();
//  		collect(tag("lightning-base-combobox-item"));
//  		ascend();
//  		ascend();
  		//collect(tag("lightning-base-combobox-item"));
  		//descend(text("Country"));
         
         //AutoAPI Account gqrbmx
         //AutoAPI Client zapgmz
         
//  		focus(Modal.CONTAINER);
//  		descend(text("Contact"));
//  		traverse();
//  		descend(tag("input"));
//  		String currentAssignedTo = fetch(ElementData.TEXT);
//  		System.out.println("currentAssignedTo " + currentAssignedTo);
  		
         
         //Modal.lookUp(NewJob.CONTACT, "AutoAPI Client zapgmz");
         
         ////*[contains(concat(' ', normalize-space(@class), ' '), ' modal-container ')]//*[(text()='Country' )]/following-sibling::*[1]]//*[1]//*[1]//*[1]//*[1]/./..//lightning-base-combobox-ite
         
// 		focus(Modal.CONTAINER);
// 		descend(text("Country"));
// 		Browser.scrollTo();
// 		traverse();
// 		descend();
// 		descend();
// 		descend();
// 		descend();
// 		pause(1);
// 		touch();
// 		ascend();
//  		collect(tag("lightning-base-combobox-item"));
//  		Parq.show();
// 		choose(txt("United Kingdom"));
// 		touch();
         
//         
//       focus(css("data-component-id","flexipage_tabset"));
//       descend(tag("li"));
//       ascend();
//       ascend();
//       collect(css("role","presentation"));
//       contains(ACTIVITY);
//       contains(CHATTER);
//       contains(CHNAGELOG);
//       contains(APPROVALHISTORY);

       
//       descend();
//       collect(css("role","tablist"));
//       Parq.show();
         
//         focus(css("role","tablist"));
//         focus(css("role","tablist"));
//         collect(css("slot","tabs"));
         
        //focus(className("slds-tabs_default__item"));
//        focus(css("data-component-id","flexipage_tabset"));
//        descend(tag("li"));
//        descend(text("Details"));
//        ascend();
//        //ascend();
//        ascend(tag("div"));
        //traverse();
        //descend(text("Details"));
        //ascend();
//        ascend();
//        descend(tag("a"));
        //collect(css("role","tab"));
        Parq.show();
// 		ascend(tag("article"));
// 		descend(Html.H2);
        

       
//       focus(className("forcegenerated-flexipage-template"));
//       descend(css("data-target-selection-name","flexipage_tabset"));
//       descend();
//       ascend();
//       ascend();
//       ascend();
//       ascend();
       //ascend();
       //traverse();
//       descend(tag("a"));
//       collect(Html.ANCHOR);
//       Parq.show();
       //ascend();
       //descend(css("data-target-selection-name","flexipage_tabset"));
       
         
//      focus(text("Master SO"));
//      ascend();
//      traverse();
//      descend(tag("a"));
//      descend(tag("span"));
//      contains("SO0000384376");
      //String currentAssignedTo = fetch(ElementData.TEXT);
      
      
         //ascend();
         //ascend();         
         //traverse();
         
//         focus(className("slds-tabs_card"));
//         descend();
//         collect(css("data-col-key-value","4-lstListViewRowLevelAction-4"));
//         Parq.show();
         
         
//         focus(css("title","OT Rate 1"));
//         ascend(tag("td"));
//         traverse();
//         traverse();
//         traverse();
//         descend(text("Show Actions"));
//         touchJS();
//         pause(3);
//         focus(text("Delete"));
//         pause(3);
//         touchJS();
//         pause(3);
//         focus(text("Delete")).touchJS();
         //focus(css("data-col-key-value", "4-lstListViewRowLevelAction-4"));
         
//       focus(text("Show more actions"));
//       touchJS();
         
//      	List<WebElement> showmoreactionsbtns = getDriver().findElements(By.xpath("//tbody//li"));
//    	pause(3);
//    	showmoreactionsbtns.get(1).click();
//        focus(text("Delete"));
//        touchJS();
//        focus(text("Delete")).touch();
         
         //TPLibrary.recallPlacement();
//         APILibrary apiLib = new APILibrary();
//         References references = apiLib.ref;
         //apiLib.updateOTRate("OT 2.0","a0S3L0000001dAEUAY");
         
//         references = apiLib.getRateIdWithIndexNumber(Rate.Field.PLACEMENT.getValue(), "a0S3L0000001dAEUAY", 2);
//         System.out.println("placement rate is is "+ references.getPlacementRate());
//         references = apiLib.updateRateCompany(references.getPlacementRate(), "Special Rate 1");
         
         //Modal.load();         
         //focus(className("slds-modal slds-fade-in-open slds-modal_large cCAP_CC_EmailComposer"));
         //contains("OT Bill Rate: 100.00 GBP");
         
         //focus(text("OT Bill Rate: 100.00 GBP"));
         
         //APILibrary apiLib = new APILibrary();
         //References references = apiLib.ref;
         //references = apiLib.updatePlacementayrollSubType("a0S3L0000001dAdUAI");
         
//     	focus(Modal.CONTAINER);
//		descend(text("Salutation"));
//		Browser.scrollTo();
//		traverse();
//		descend();
//		descend();
//		descend();
//		descend();
//		pause(1);
//		touch();
//		ascend();
////		traverse();
//		collect(tag("lightning-base-combobox-item"));
//		Parq.show();
//		choose(txt("Mr."));
//		touch();
//     	Parq.getDriver().switchTo().defaultContent();
//    	pause(2);
//        Browser.refresh();
//        Page.handleSpinner();
//        pause(2); 
//        frame();
//        pause(2);
//    	Parq.getDriver().switchTo().frame(Parq.getDriver().findElement(By.xpath("//div[@id='candidateSearch']//IFRAME")));
         
        //CCLibrary.candidateSearch("Henry cppaxyli");         
//        focus(css("value","More"));
//        touchJS();
//        focus(text("View CV")).touchJS();
//        Page.sleep(5);
//        Parq.show();
//         frame();
//         Parq.show();
//        contains("CURRICULUM VITAE");
//        contains("Address: 61 Aldwych, Kingsway, Holburn, Hounslow, Waterloo Bridge, Central London");
        
//         focus(text("Henry cppaxyli"));
//         touch();
         
//         CCLibrary.candidateSearch("AutoAPI Candidate poywzd");
//         focus(text("Add to Shortlist"));
//         touchJS();
//         focus(className("button shared_with_input docid docidlink-calllist"));
//         descend(tag("span"));
//         touchJS();
         
         //touchJS();
         
         
//         focus(Modal.SLDS_CONTAINER);
//         focus(name("name"));
//         touchJS();
//         compose("test");
//         pause(4);
//         focus(css("value","Save"));
//         touchJS();
         
         
         //CCLibrary.candidateSearch("AutoAPI Candidate fydpcm");
        // main.java.customerconnect.po.Form.select(ADD_TO_LONGLISTS);
         //Modal.load();
//        Parq.getDriver().switchTo().defaultContent(); 
// 		focus(Modal.SLDS_CONTAINER);
 		
//  		Parq.show();
//  		focus(className("slds-form-element__control"));
//  		descend(tag("input"));  		
//  		touch();
 
  		
  		
  		//focus(css("span","Search icon"));
// 		focus
// 		focus(text("Recently Viewed"));
// 		//descend();
// 		touchJS();
// 		pause(2);
// 		compose("AutoAPI Account eqamsq - Auto Job tdsxbk");
//		pause(2);
//		focus(partialText("AutoAPI Account eqamsq - Auto Job tdsxbk"));
//		touch();
		//descend(text("Job name"));
         
         //AutoAPI Account eqamsq - Auto Job tdsxbk
         
//         CCLibrary.candidateSearch("AutoAPI Candidate fydpcm");
//         main.java.customerconnect.po.Form.select(ADD_TO_LONGLISTS);
//         Parq.getDriver().switchTo().defaultContent();      
//         focus(className("slds-modal__container"));         
//        CandidateDetails.sldslookUpNewByPlaceHolder(CandidateDetails.Label.RECENTLY_VIEWED, "AutoAPI Account eqamsq - Auto Job tdsxbk");
//         Toast.validateMessage(LONGLIST_SAVED);
         
         //Parq.getDriver().switchTo().defaultContent(); 
//         focus(className("slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right"));
// 		descend(tag("input"));
// 		touch();
         
       //Parq.getDriver().switchTo().defaultContent();
       //Parq.getDriver().switchTo().frame(Parq.getDriver().findElement(By.xpath("//div[@id='candidateSearch']//IFRAME")));
         
//         focus(css("data-id","searchinput"));
//         touchJS();
//         compose("AutoAPI Account eqamsq - Auto Job tdsxbk");
         
         
         
//         focus(className("action-button add_to_call_list"));
//         touchJS();
//         ArrayList<String> tabs2 = new ArrayList<String> (Parq.getDriver().getWindowHandles());
//         Parq.getDriver().switchTo().window(tabs2.get(1));
//         pause(3);
//         focus(text("Create new"));
//         ascend();
//         touch();
//         focus(text("Name"));
//         ascend();
//         descend(tag("input"));
//         compose("test");         
//         focus(text("Select type"));
//         pause(1);
//         touch();
//         pause(1);
//         focus(text("Candidate"));
//         pause(3); 
//         touchJS();
//         unframe();
//         focus(name("Add2"));
//         touch();
//         Toast.validateMessage(DUPLICATE_RECORD);
         
         

    
         
         
//         WebElement frame = Parq.getDriver().findElement(By.xpath("//div[@class='windowViewMode-normal oneContent active lafPageHost']//iframe"));
//         Parq.getDriver().switchTo().frame(frame);
         
//         Parq.getDriver().switchTo().frame(0);
//         System.out.println("selenium switched to frame");
         ////*[(text()='Last Meaningful Activity Date' )]/./.././..//input
         
//         Parq.getDriver().switchTo().defaultContent();
//         frame();
//         Parq.getDriver().switchTo().frame(Parq.getDriver().findElement(By.xpath("//div[@id='candidateSearch']//IFRAME")));
         
//         focus(className("CalendarMonthGrid_month__horizontal CalendarMonthGrid_month__horizontal_1"));
//         //descend(tag("tr"));
//         //descend();
//         traverse();
//         descend(tag("tr"));
//         descend(tag("td"));
//         collect(tag("aria-label"));
//         Parq.show();
//         
//         focus(text("CV Last Updated"));
//         touchJS();
//         Page.sleep(5);
//         focus(text("Choose specific date or range"));
//         touchJS();
//         Page.sleep(5); 
//         
//         Calendar cal = Calendar.getInstance();
//         SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
//         Format f=new SimpleDateFormat("EEEE, MMMMM d, yyyy");
//         String str = f.format(new Date());
//         System.out.println("Day Name: " + str);
//         focus(css("aria-label",str));
//         touchJS();
//         Page.sleep(5); 
//         focus(text("Done"));
//         touchJS();
         
         //Selected. Friday, August 4, 2023
         
//      focus(className("CalendarMonth CalendarMonth_1"));
//      descend(tag("td"));
//      focus(className("CalendarDay CalendarDay_1 CalendarDay__default CalendarDay__default_2 CalendarDay__today CalendarDay__today_3"));
//      touchJS();
//      Page.sleep(5);      
//      focus(text("Done"));
//      touchJS();
      
       //returns a Calendar object whose calendar fields have been initialized with the current date and time  
         
         //Selected. Friday, August 4, 2023

       
         
//         
//         focus(text("Current/Last Employer"));
//         touchJS();
//         Page.sleep(5);         
//         focus(text("Current/Last Employer"));
//         ascend();
//         ascend();
//         descend(tag("input"));
//         clear();
//         Page.sleep(2);
//         compose("Test Manager");
//         Page.sleep(5);
//         Browser.enter();
         
         
         
         
//         focus(css("id", "facet-tr__customdate2"));
//         descend(tag("input")).touchJS();
         
//        focus(text("Last Meaningful Activity Date"));
//        ascend();
//        ascend();
//        descend(tag("input")).touchJS();
//        ascend();
//        traverse();
        
        
//         touchJS();
//         Page.sleep(10);
//         
//  		focus(css("value", "=today"));
//  		pause(3);		
//  		touch();
         
//         focus(text("Last Meaningful Activity Date"));
//	       ascend();
//	       ascend();
//	       ascend();
//	       descend(tag("span"));
//	       touchJS();
//         collect(Html.SPAN);
//         Parq.show();
//         ascend();
//         ascend();
//         ascend();
//         descend(tag("input"));
//         touchJS();
//         
         
//         int framesize = Parq.getDriver().findElements(By.xpath("//iframe")).size();
//         System.out.println("selenium switched to frame" + framesize);
         
//       	try {
//     		 Parq.getDriver().switchTo().defaultContent();
//            if(Parq.getDriver().findElements(By.xpath("//iframe")).size() > 0) {
//               WebElement containerFrame = Parq.getDriver().findElement(By.xpath("//iframe"));
//               //Parq.getDriver().switchTo().frame(containerFrame);
//               
//               Parq.getDriver().switchTo().frame(Parq.getDriver().findElement(By.xpath("//DIV[@ID=\"candidateSearch\"]//IFRAME")));
//               
//               System.out.println("selenium switched to frame ***********************8" + containerFrame);
//               
//               Parq.getDriver().findElement(By.xpath("//*[(text()='City or Post Code' )]")).click();
//               
////               focus(text("City or Post Code"));
////               touchJS();
////               Parq.show();
//
//           }
//		} catch (NoSuchFrameException e) {
//			System.out.println("selenium notswitched to frame");
//		} catch (Exception e) {
//			System.out.println("selenium not switched to frame-- fail");
//		}
         
//     	try {
//		   Parq.getDriver().switchTo().frame(0);
//		} catch (NoSuchFrameException e) {
//			System.out.println("selenium switched to frame");
//		} catch (Exception e) {
//			System.out.println("selenium switched to frame-- fail");
//		}
         
     	Parq element =Parq.show();
         
//        Parq.getDriver().switchTo().frame( Parq.getDriver().findElement(By.cssSelector("TR1_TextkernelIframe")));
//        focus(text("City or Post Code")).touchJS();
// 		Actions a = new Actions( Parq.getDriver());
// 		WebElement source =  Parq.getDriver().findElement(By.cssSelector("#draggable p"));
// 		WebElement target =  Parq.getDriver().findElement(By.cssSelector("#droppable p"));
// 		System.out.println(target.getText());
// 		try {
//			Thread.sleep(1000L);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
// 		a.moveToElement(source).dragAndDrop(source, target).build().perform();
// 		System.out.println(target.getText());
         
         
         //unframe();
//         frame();         
         
         
     
         //perform(new CandidateCvHandler("BS13XE", "candidatname", "email", 240));
         
//          origin(); 
//     	 frame();
//         focus(id("searchtext"));
//  
//         focus(id("submitbutton"));
//         touchJS();
         //focus(className("resultitems"));
//         collect(Html.LIST_ITEM);
//         range();
//         Parq.show();
//         contains("BS13XE");
//         Parq txtExist = present(txt("AUTOMATION"));
//         unframe();
         
         
         //perform(new CandidateCvHandler("Active", 240));
         
         
         
//          String actEmailTemplates = "";         
//          String expectedEmailTemplates = "all List – Vorlage,"
//             + "DE_Candidate_External Interview Confirmation,"
//             + "DE_Candidate_Registration Interview Confirmation,"
//             + "DE_Candidate_Revenue Recognition,"
//             + "DE_Client_Interview Confirmation_Multiple Candidates,"
//             + "DE_Client_Interview Confirmation_Single Candidates,"
//             + "DE_Client_Revenue Recognition,"
//             + "DE_Page Contracting Signature with Unsubscribe Link,"
//             + "DE_Page Resourcing Signature with Unsubscribe Link,"
//             + "Page Contracting Signature,"
//             + "Page Resourcing Signature";
//        
//         frame();         
//         focus(tagContains(LABEL, "Select Email Folder"));         
//         ascend();
//         touch();
//         descend(Html.SPAN);
//         ascend();
//         ascend();
//         ascend();
//         collect(Html.SPAN);
//         choose(txt("Germany - German Email Templates"));
//         touch();
//         focus(tagContains(LABEL, "Email Template"));         
//         ascend();
//         touch();
//         descend(Html.SPAN);
//         ascend();
//         ascend();
//         ascend();
//         collect(Html.SPAN);
//         String text = fetch(ElementData.TEXT);
//         String[] arrSplit =  text.split("[\r\n]+");
//         
//         System.out.println("actualdEmailTemplates is ---->" +  arrSplit);
//         
//        actEmailTemplates = "";
// 	    for (int i=1; i < arrSplit.length; i++) {
// 	    	actEmailTemplates= actEmailTemplates + arrSplit[i] + ",";           
// 	    }         
// 	    String actualEmailListValues = actEmailTemplates.substring(0, actEmailTemplates.length() - 1);        
// 	    Assert.assertEquals(expectedEmailTemplates, actualEmailListValues );
      

         
        
         //collect(className("slds-listbox__option-text slds-listbox__option-text_entity"));
         
//         descend(Html.SPAN);
//         descend(Html.SPAN);
//         origin();
//         collect(tag("span"));
//         choose(txt("Germany - German Email Templates"));
//         touch();
//         pause(3);         
//         focus(tagContains(LABEL, "Email Template"));         
//         ascend();
//         touch();
//         descend(Html.SPAN);
//         descend(Html.SPAN);
//         origin();
//         collect(tag("span"));
//	     String text = fetch(ElementData.TEXT);
//	     System.out.println("text value is " +text);
//	     System.out.println("--------------------------------");
//	     String[] arrSplit =  text.split("[\r\n]+");
//	     System.out.println("arrSplit value is " +arrSplit);
//         Parq.show();
//         
//         if ( ArrayUtils.contains( arrSplit, "Germany - German Email Templates" ) ) {
//        	   System.out.println("10 is present in the list");
//             } else {
//           System.out.println("10 is not present in the list");
//        }
//         
         //descend(Html.SPAN);
//         origin();
//         collect(Html.SPAN);
//         Parq.show();
//         System.out.println("<-------------------->");
//         ascend();
//         ascend();
//         descend(Html.SPAN);
//         pause(3)
         //traverse();
	     //collect(tag("span"));
         //descend(Html.SPAN);
         //collect(Html.SPAN);
         //traverse();
         //descend(Html.SPAN);
         
         //collect(tag("span"));
         //collect(css("title", "Next"));
         //Parq.show();
         
         
         //collect(text("Next"));
         //choose(Index.ListReference.HEAD);
 	
	     
//	     focus(CONTAINER);
//	        descend(Html.INPUT);
//	        touch();
//	        focus(CONTAINER);
//	        descend(Html.UNORDEREDLIST);
//	        collect(Html.LIST_ITEM);
//	     descend();
//	     descend();
//	     descend();
//	     pause(1);
//	     ascend();
//	     traverse();
//	     collect(tag("lightning-base-combobox-item"));
//	     String text = fetch(ElementData.TEXT);
        
//         String[] arrSplit =  Modal.returnPicklistValuesFromDropdown("Select Email Folder");
//         String actualPickListValues = "";
//         for (int i=1; i < arrSplit.length; i++) {
//        	 actualPickListValues= actualPickListValues + arrSplit[i] + ",";           
//         }   
//         System.out.println("actualPickListValues is " + actualPickListValues);
         
        //focus(Modal.CONTAINER);
 		//descend(text("Current Industry Level 1"));
 		//focus(tagContains(Html.Tag.LABEL, "Current Industry Level 1"));
// 		Browser.scrollTo();
// 		traverse();
// 		descend();
// 		descend();
// 		descend();
// 		descend();
// 		pause(1);
// 		touch();
// 		ascend();
// 		traverse();
// 		collect(tag("span"));
// 		choose(txt("Business Services"));
// 		touch();
         
//         focus(className("slds-card__header-title"));
//         descend(className("lds-shrink-none slds-m-right--xx-small"));
//         String currentcallListCount = fetch(ElementData.TEXT);
//         System.out.println("currentcallListCount is "+ currentcallListCount);
//         Assert.assertEquals("(0)", currentcallListCount );
        
         
         //descend(tag("span"));
         //descend(Html.SPAN);
         
         //focus(partialText("SOLN")).touchJS();
         
//         String assignedTo = "QA AUTO UK FE MAIN";
//         Browser.pageDown(); 
//         Page.loadDetails();
//         WebElement task =  getDriver().findElement(By.xpath("//div[text()='You had a task with ']/ancestor::div[@class='slds-media__body']//following-sibling::div//del[text()='Complete your registration']"));
//         Actions actions = new Actions(Parq.getDriver());
//         actions.moveToElement(task).click().build().perform();
//         pause(5);
//     	focus(text("Assigned To"));
//         ascend();
//         traverse();
//         String currentAssignedTo = fetch(ElementData.TEXT);
//         System.out.println("current assigned To value is " + currentAssignedTo);
// 		contains(assignedTo);
         
         
//         focus(text("Show more actions"));
//         touchJS();
         //Modal.dropdown(Label.RECORD_STATUS, "Addedin Error");
         
//     	focus(Modal.CONTAINER);
//		descend(text("Record Status"));  // to <span> in modals
// 		ascend();
// 		ascend();
// 		descend(Html.BUTTON);
// 		touch();
// 		pause(3);
// 		focus(css("title", "Added in Error"));
// 		pause(3);		
// 		touch();
         
//         WebElement textvalue = Parq.getDriver().findElement(By.xpath("//div[@class ='col-lg-3 filter-search-offer']//span"));
//      	 System.out.println("textvalue is " + textvalue.getText()); 
         //focus(text("Submit your CV")).touch();
         
//         focus(text("Show more actions"));
//         touchJS();
//         focus(text("Edit"));
//         touchJS();
         

//         

         
//         https://testfile--preprod.sandbox.lightning.force.com/lightning/r/Contact/0033M00001JPJd9QAH/related/AttachedContentNotes/view
//         https://testfile--preprod.sandbox.lightning.force.com/lightning/r/Contact/0033M00001JPJd9QAH/related/AttachedContentDocuments/view
        		 
         
         
//         final String INTERVIEW_SCHEDULE = "Interview Schedule";
//         final String UNTITLED_NOTE_TEXT = "Test Automation - Client Notes heading";
//         final String ENTER_A_NOTE_TEXT = "Test Automation - Client Notes Paragraph text";
//         final Locator untitledNote = className("inputText notesTitle flexInput slds-form-element");
//         final Locator note = className("ql-editor ql-blank slds-rich-text-area__content slds-text-color_weak slds-grow");
         
       
         //perform(new QuickLinksHandler(NOTES));
//         PageAction.select(PageAction.Type.NEW);
//         Dialog.input(untitledNote, UNTITLED_NOTE_TEXT);
//         Dialog.inputIntoParagraph(note, ENTER_A_NOTE_TEXT);
//         pause(10);
        
         //focus(className("slds-button slds-button_neutral hideDoneButton slds-m-left--x-small")).touchJS();

         
//     	String customerAgreementID ="";
//		List<WebElement> listOfResults = getDriver().findElements(By.xpath("//table[@role='grid']//tbody"));
//	    System.out.println(listOfResults.size());
//		for (int i = 0; i < listOfResults.size(); i++) {			
//			String accountrecordtype=listOfResults.get(i).getText();
//			//System.out.println("customer agreement is "+accountrecordtype);
//			if (accountrecordtype.equals("Others")) {
//				customerAgreementID=listOfResults.get(i-2).getText();
//				System.out.println("customerAgreementID is "+customerAgreementID);
//				break;				
//			}
//		}
		
//		String contractType = "Retainer Agreement";
//		WebElement customerAgreementID =getDriver().findElement(By.xpath("//td[contains(.,'" + contractType + "')]/preceding-sibling::td[2]//a[1]"));
//		System.out.println("customerAgreementID is "+customerAgreementID.getAttribute("title"));		
//		focus(text("AGM-05252023-13763")).touch();
         
//         focus(className("windowViewMode-normal"));
//         descend(partialText("NS-"));
//         touch();
         
         //CustomerConnectBroadBeanForm.select(POST_TO_BROADBEAN);
         //######### End action - SALESFORCE page ##########

         //######### Start action - BROADBEAN page ##########
//         Browser.switchWindow(Index.WindowIndex.NEXT);
//         Page.sleep(5);
//
//         //fill the BB form to post the above created job
//         BroadBean.selectAdvertLanguage(Language.en_GB);
//         BroadBean.selectGoldenQA(country ); 
         

         //Modal.load();
         
//         Modal.lookUp(NewJob.ACCOUNT, "AutoAPI Account mshbcw");
//         Modal.selectValueFromDropDown("Status","Lost");
         
//         focus(Modal.CONTAINER);
//         pause(5);
//         descend(tag(SPAN, "Child Oportunity"));
//         ascend();
//         traverse();
//         touch();         
         
//         Menu.select(Menu.Type.JOB_LEADS);
//         PageAction.select(PageAction.Type.NEW);
//         Modal.radioSelect(Contact.Field.OPPORTUNITY);
//         Modal.select(Modal.Actions.NEXT);
//         Modal.load();
         
//         focus(Modal.CONTAINER);
//         focus(tagContains(Html.Tag.LABEL, "Status" ));
//         touchJS();       
//         traverse();
//         descend();
//         descend();
//         descend();
//         descend();
//         pause(1);
//         ascend();
//         traverse();
//         collect(tag("lightning-base-combobox-item"));
//         String text = fetch(ElementData.TEXT);
//         System.out.println("First element Name is " + text);
//         String[] arrSplit =  text.split("[\r\n]+");
//         String expectedPickListValues = "Qualification,In Progress,Submitted,Negotiation,Win Pending,Won,Lost,Closed";
//         String actualPickListValues = "";
//         for (int i=1; i < arrSplit.length; i++) {
//        	 actualPickListValues= actualPickListValues + arrSplit[i] + ",";           
//         }         
//         actualPickListValues = actualPickListValues.substring(0, actualPickListValues.length() - 1);
//         
//         Assert.assertEquals(expectedPickListValues, actualPickListValues );
//         
//         System.out.println("actualPickListValues are ----> " + actualPickListValues);     
        
         //System.out.println("First element Name is " + fetch(ElementData.TEXT));
              
         //Parq.show();

         
         
//         focus(Modal.CONTAINER);
//         descend(text("Status"));
//		 ascend();
//		 ascend();
//		 ascend();
//		 descend(tag("span"));
		 //descend();

//		 traverse();
//		 touch();
//		 collect(Html.SPAN);
//		 Parq.show();
         
         
         
//        focus(Modal.CONTAINER);
// 		descend(text("NetSuite Contact"));  // to <span> in modals
//  		ascend();
//  		ascend();
//  		descend(tag("input"));
//  		touch();
//  		pause(3);
//  		focus(css("title", "AutoAPI Client glikih"));
//  		pause(3);		
//  		touch();
         
         
         
//        focus(Modal.CONTAINER); 		
// 		descend(tag(BUTTON, "Save"));
 		//ascend();
 		//touch();
         
//        	focus(className("slds-grid"));
//        	//descend(tag("tbody"));
//            descend(tag("span"));
//            String text = fetch(ElementData.TEXT);
//            System.out.println("text is ************"+text);
//         focus(css("data-label", "Application Number"));
//         descend(tag("slot"));
//         descend(tag("span"));
//         String text = fetch(ElementData.TEXT);
//         System.out.println("text is ************"+text);
        
         
//         focus(Modal.CONTAINER);
//         //collect(Html.LABEL).choose(enc("Alert End Date")).traverse().touch();
//         focus(name("CAP_CC_Page_Alert_End_Date__c"));
//         compose(GeneralCommonFunctions.minusDaysToDate_ddMMYYY(0));
//         //descend(className("selectedDate"));
//         //touch();
//        focus(Modal.CONTAINER);
// 		descend(text("Perm Payment Terms"));  // to <span> in modals
// 		ascend();
// 		ascend();
// 		descend(Html.SPAN);
// 		touch();
// 		pause(3);
//		focus(css("title", "2 DAYS"));
//		pause(3);		
//		touch();
         
//        focus(Modal.CONTAINER);
//        descend(text("Perm Payment Terms"));  // to <span> in modals
// 		ascend();
// 		ascend();
// 		ascend();
// 		touch();
// 		collect(tag("lightning-base-combobox-item"));
// 		choose(Index.ListIndex.THIRD);
// 		touchJS();
         
//         focus(tagContains(Html.Tag.LABEL, "Perm Payment Terms"));
//         touchJS();       
//         traverse();
//         descend();
//         descend();
//         descend();
//         descend();
//         pause(1);
//         ascend();
//         traverse();
//         collect(tag("lightning-base-combobox-item"));
//         choose(Index.ListIndex.THIRD);
//         touchJS();
 		
 		//descend(tag("span"));
 		//descend(tag("span"));
 		//touch();
 		//collect(Html.SPAN);
 		//descend();
 		//descend(tag("span")); 
 		//descend(tag("span"));
 		//touch(); 
 		//Parq.show();
 		//collect(Html.SPAN);
 		//Parq.show();
 		
 		//focus(className("visible"));
 		//collect(Html.LIST_ITEM);
 		//Parq.show();
 		//choose(Index.ListIndex.FOURTH);
 		//touch();
 		
 		//descend(Html.SPAN);
 		//touch();
// 		descend();
 		//collect(Html.SPAN);
 		
// 		focus(className("visible"));
// 		collect(Html.LIST_ITEM);
// 		choose(1);
// 		touch();
         
 		
// 		focus(className("visible"));
//		collect(Html.LIST_ITEM);
//		choose(1);
//		touch();
// 		focus(className("visible"));
// 		collect(Html.LIST_ITEM);
// 		choose(2);
// 		touch();
         
//        focus(Modal.CONTAINER);
// 		descend(text("Street"));
// 		ascend();
// 		ascend();
// 		descend(tag("textarea"));
// 		touch();
// 		compose("this is a test");
         
//        focus(Modal.CONTAINER);
// 		descend(text("Industry Level 1"));  // to <span> in modals
// 		ascend();
// 		ascend();
// 		descend(tag("button"));
// 		touch();
// 		focus(css("title", "Retail"));
// 		touch();
        // Modal.dropdown(Label.INDUSTRY_LEVEL2, "Rental");
         
         
         
// 		traverse();
// 		descend(Html.ANCHOR);
 		//stouch();
// 		pause(3);
// 		focus(css("title", "Retail"));
// 		pause(3);
// 		touch();
         
//		focus(text("Source"));
//		traverse();
//		descend(leaf());
//		touchJS();
//		ascend(tag("lightning-base-combobox"));
//		collect(Html.SPAN);
//		choose(txt("CV Library")).touch();

//        focus(text("Edit Page Country"));
//	    touchJS();
//  		focus(text("Page Country"));
//  		traverse();
//  		descend(leaf());
//  		touchJS();
//  		ascend(tag("lightning-base-combobox"));
//  		collect(Html.SPAN);
//  		choose(txt("United Kingdom")).touch();	

  		//ascend();
//        traverse();
//        collect(tag("lightning-base-combobox-item"));
//  		show();
		//focus(className("select-options"));
//		descend(Html.UNORDERED_LIST).collect(Html.LIST_ITEM);		
//		choose(txt("United Kingdom")).touch();	
  		//compose("United Kingdom");
//        focus(className("select-options"));
//		descend(Html.UNORDERED_LIST).collect(Html.LIST_ITEM);		
//		choose(txt("United Kingdom")).touch();
//  		collect(Html.SPAN);
//  		Parq.show();
  		//choose(txt("United Kingdom")).touch();


  		

  		
//  		ascend();
//  		ascend();
//  		traverse();
//  		descend(leaf());
//  		touchJS();
//  		Page.sleep(5);
//  		descend(tag("select"));
//  		collect(tag("option"));
//  		focus(className("select-options"));
//  		descend(Html.UNORDERED_LIST).collect(Html.LIST_ITEM);		
//  		choose(txt("United Kingdom")).touch();	
   
                
       
         
         //traverse();
         //sdescend(tag(SPAN));
//         touchJS();
//         focus(text("Japan"));
//         touch();
//         focus(css("title", "Save"));
//         touch();
         
//         Modal.load(); 	    
//         focus(text("Job Type"));
//         ascend(tag("div"));
 		//descend(tag("select"));
 		//collect(tag("option"));
// 		touch();
// 		pause(3);
// 		choose(txt(value));
// 		touch();
// 		pause(3);
// 		pause(3);
         
//            focus(text("Contact Owner"));
//			ascend();
//			ascend();
//			ascend();
//			descend(tag("a"));
//			descend(tag("SPAN"));
//			String ContactOwner = fetch(ElementData.TEXT);
//			System.out.println("ContactOwner is "+ContactOwner);
//			Assert.assertEquals(ContactOwner, "QA AUTO UK FE MAIN");
         
         //focus(text(("Alert")));
         
//         focus(text("Retain Contact Ownership"));
//         ascend();
//        // ascend();
//         //ascend();
//        // Parq element =ascend();
//         //descend();
//         Parq element =traverse();
//         descend(tag("input"));
////         show();
//         touchJS();
        
         
         //Parq element =Parq.show();
         
//         String alertImagvalue= Parq.getDriver().findElement(By.xpath("//*[(text()='Alert' )]//..//img")).getAttribute(("alt"));
//         System.out.println("alertImagvalue is " + alertImagvalue);
         
         
//         boolean alertImagvalue1= Parq.getDriver().findElement(By.xpath("//*[(text()='Alert' )]//..//img")).isDisplayed();
//         System.out.println("alertImagvalue1 is " + alertImagvalue1);
//         Assert.assertEquals(alertImagvalue1, true);
         
         
//         List lstElmntLC = Parq.getDriver().findElements(By.xpath("//*[(text()='Alert' )]//..//img"));        
//         System.out.println("lstElmntLC�size�is "+lstElmntLC.size());
//  		 if(lstElmntLC.size()<0){
//  		  Assert.fail("Alert field in the banner is updated with a red exclamation mark ");
//  		  }else {
//  	      System.out.println("Alert field is not on the banner is updated with a red exclamation mark");
//  		 }
         
//         String field = "No Longer Looking for a Job";
//    	 WebElement checkBox = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'"+field+"')]//span[@class='slds-checkbox_faux'][1]"));
//    	 //WebElement checkBox  = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'Health & Safety Risk')]/ancestor::lightning-input//input"));
//    	 JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
//         String checkBoxTicked = (String) js.executeScript("return window.getComputedStyle(arguments[0],'::after').getPropertyValue('content');", checkBox);
//         System.out.println("checkBoxTicked value is " + checkBoxTicked);  
//         Assert.assertTrue(checkBoxTicked.startsWith("\""));
//         Assert.assertTrue(checkBoxTicked.endsWith("\""));
         
//     	focus(Modal.CONTAINER);
//		focus(className("quick-actions-panel"));
//		descend(text("Not Looking For Job Reasons"));
//		ascend();
//		traverse();
//		descend(Html.ANCHOR);
//		touch();
//		focus(className("select-options"));
//		descend(css("title", "Decided Not to Move"));
//		touch();
		//descend();
		//descend(tag("select"));
		
		//ascend();
		//traverse();
		//descend(tag("select"));
//		collect(tag("option"));
//		choose(txt(value));
//		touch();
         
//      focus(text("Last Meaningful Activity Date"));
//   	  ascend();
//   	  ascend();
//   	  descend(tag("lightning-formatted-text"));
//   	  String lastMeanigfulActivityDate = fetch(ElementData.TEXT);
//	  System.out.println("lastMeanigfulActivityDate is "+lastMeanigfulActivityDate);
//	  Assert.assertEquals(GeneralCommonFunctions.currentDate(), lastMeanigfulActivityDate);
         
//         String actmostAdvancedRecruitmentStageDate = "";
//         actmostAdvancedRecruitmentStageDate = EntityHeaderSection.getMostAdvancedRecruitmentStageDate();
//         System.out.println("actmostAdvancedRecruitmentStageDate is "+ actmostAdvancedRecruitmentStageDate);
//         Assert.assertEquals(GeneralCommonFunctions.currentDate(), actmostAdvancedRecruitmentStageDate);
         
//         String value ="Your AutoAPI Client qjxgmb is linked to the following job lead https://testfile--sitest.sandbox.my.salesforce.com/a1A3M000000YQ3k which has been assigned to Domenec Gilabert. You do not need to take any action.";
         
         //focus(text("Refer Client"));
         //touchJS();         
         //focus(text("Chatter"));
         
         //String URL ="https://testfile--sitest.sandbox.my.salesforce.com";
         //String sfID ="0033M00001IRzdIQAT";
         //focus(text("QA AUTO Temp SysAdmin"));
        
         //Parq.frame();
//         focus(text("QA AUTO Temp SysAdmin"));
//         String value = "https://testfile--sitest.sandbox.my.salesforce.com/0033M00001IRzdIQAT";
     
         

         
         
         
//         focus(text("Refer Job Lead"));
         //Parq element =Parq.show();
         
//        focus(text("City"));         
//        focus(className("slds-select"));
// 	    touch();
// 	    Parq element =compose("UK39-Weybridge");
// 	    touchJS();
         
        //Country France City Rennes Brand MP-Michael Page
         
//        focus(className("modal-container slds-modal__container"));
// 		focus(className("slds-modal__content slds-p-around--medium"));	
// 	    descend(text("Team"));
// 		ascend();
// 		ascend();		
// 		ascend();	
// 	    Page.sleep(2);
// 	    touch();
// 	    Page.sleep(2);
// 	    Parq element =collect(tag("option"));
// 	   choose(Index.ListIndex.SECOND).touch();
// 	    touchJS();
// 	   pause(2);
//       probe(text("OK"));
//       touch();         
//         focus(css("title","Most Advanced Recruitment Stage Date"));        
//         Parq element =traverse();
//	     descend(tag("lightning-formatted-text"));
//	     String actmostAdvancedRecruitmentStageDate =fetch(ElementData.TEXT);
//	     System.out.println("actmostAdvancedRecruitmentStageDate is "+actmostAdvancedRecruitmentStageDate);
//	     Assert.assertEquals(GeneralCommonFunctions.currentSalesForceDate(), actmostAdvancedRecruitmentStageDate);
	     
//         String actmostAdvancedRecruitmentStageDate = EntityHeaderSection.getMostAdvancedRecruitmentStageDate();
//         System.out.println(actmostAdvancedRecruitmentStageDate);
//         Assert.assertEquals(GeneralCommonFunctions.currentDate(), actmostAdvancedRecruitmentStageDate);
//         Parq element =traverse();
         
         
         
	     //String MostAdvancedRecruitmentStageDate =fetch(HtmlAttribute.ALT);
	     //System.out.println("MostAdvancedRecruitmentStageDate is "+MostAdvancedRecruitmentStageDate);
	        
         
         
//         try {
//         focus(css("title","Most Advanced Recruitment Stage Date"));        
//         Parq element =traverse();
//         descend(tag("img"));
//         String currentRecriutmentOwner =fetch(HtmlAttribute.ALT);
//        c
//         } catch (Exception e) {
//        	 e.printStackTrace();
//         }
         
//         focus(tagContains(SPAN, "Most Advanced Recruitment Stage"));
//    	 ascend();  	
//    	 descend();
//    	 traverse();
//    	 Parq element =descend(tag("div"));
//         String currentRecriutmentOwner = fetch(ElementData.TEXT);
//         System.out.println("currentRecriutmentOwner*****************" + currentRecriutmentOwner);
         //Parq element = focus(text("ACTIVE"));
         //Parq element = Parq.show();
         
//         focus(className("modal-body scrollable slds-modal__content runtime_sales_mergeMergeFlow"));        
//         descend(tag("tbody"));
//  	     Parq element =descend(tag("lightning-formatted-lookup"));
//  	     descend(tag("a"));
//  	     
//  	     
//		String href=Parq.getDriver().findElement(By.xpath("//*[contains(concat(' ', normalize-space(@class), ' '), ' modal-body scrollable slds-modal__content runtime_sales_mergeMergeFlow ')]//tbody//lightning-formatted-lookup//a")).getAttribute(("href"));
//  	    System.out.println("hred text is "+href);
//  	    if (href.contains("0013M00001LeOugQAF")){
//  	    	System.out.println("****************");
//  	    	
//  	    }
		//Parq.show();
  	   //collect((""))
  	   //collect(tag("href"));
  	     
 	     //String deDupePriorityFirstrow = fetch(ElementData.TEXT);
// 	    System.out.println("deDupePriorityFirstrow is "+deDupePriorityFirstrow); 
         //Parq element =traverse();
//         Parq element =descend(tag(SPAN, "Select Item 2"));
//         ascend(tag("label"));         
//         touch();
//         focus(text("Next")).touch();
//         focus(text("Next")).touch();
//         focus(text("Merge")).touch();
         
         //focus(text("Jobs & Placements")).touch();
//         Parq element =focus(text("CL-03122023-38672"));
//         focus(partialText("AutoAPI Job rljoxt"));
//         focus(text("AutoAPI Client ikugbg"));
         
         //traverse();
         //Parq element =descend(tag("0-SELECTABLE_CHECKBOX-0"));
         
         //Parq element =focus(css("data-col-key-value","0-SELECTABLE_CHECKBOX-0")).touch();
         
      
         
         //focus(css("title","View Duplicates")).touch();
                 
//         focus(className("modal-body scrollable slds-modal__content runtime_sales_mergeMergeFlow"));        
//         descend(tag("tbody"));
//         descend(tag("tr"));
//         traverse();
//         Parq element =descend(tag("lightning-formatted-number"));
//         String deDupePriorityFirstrow = fetch(ElementData.TEXT).replace(",", "").replace(".", "");
//         System.out.println("deDupePriorityFirstrow is "+deDupePriorityFirstrow);     
//         
//         focus(className("slds-hint-parent slds-is-selected"));
//         descend(tag("lightning-formatted-number"));
//         String deDupePrioritysecondrow = fetch(ElementData.TEXT).replace(",", "").replace(".", "");
//         System.out.println("deDupePrioritysecondrow is "+deDupePrioritysecondrow);          
//        
//         Double d1 = Double.parseDouble(deDupePriorityFirstrow.trim());
//         Long val = d1.longValue();
//         System.out.println("first value is "+ val);
//         
//         Double d2 = Double.parseDouble(deDupePrioritysecondrow.trim());
//         Long val2 = d2.longValue();
//         System.out.println("first value2 is "+ val2);
//         
//         Assert.assertTrue(val2 < val ); 
         
//         int val=Integer.parseInt(deDupePriorityFirstrow);
//         int val1=Integer.parseInt(deDupePrioritysecondrow);
//         
//         System.out.println("val1 is "+ val1);
//         System.out.println("val is "+ val);
//
//         Assert.assertTrue(val1 > val ); 
         
         
         //Parq element =Parq.show();
         
// 		focus(Modal.CONTAINER);
// 		focus(className("deleteIcon")).touch();
// 		pause(5);
// 		focus(Modal.CONTAINER);
// 		descend(text("Account Name"));  // to <span> in modals
//		ascend();
//		traverse();
//		Parq element =descend(Html.INPUT);
//		compose("this is test");
         
         //FormData.editNationalIdenficatioNumber("National Identification Number 2","Edit National Identification Number 2","CAP_CC_National_Identification_No_2__c");
        
         
//         Modal.selectValueFromdropdown(Label.COUNTRY,"United Kingdom");
//         Parq element =Parq.show(); 
         
//         focus(Modal.CONTAINER); 
//        focus(text("Country"));
// 		ascend();
// 		traverse();
// 		Page.sleep(3);
// 		descend(leaf());
// 		Page.sleep(5);
// 		touchJS();
// 		Page.sleep(5);
         
       //*[(text()='Country' )]/
         
//        focus(className("modal-container"));
//     	descend(text("Country"));  // to <span> in modals
//     	Parq element =ascend();
//		traverse();
//		descend(Html.ANCHOR);
//		touch(); 
// 		focus(className("select-options"));
// 		descend(Html.UNORDERED_LIST).collect(Html.LIST_ITEM);		
// 		choose(txt("United Kingdom")).touch();
 		
// 		focus(Modal.CONTAINER);
//		descend(text(formField.getValue()));  // to <span> in modals
//		ascend();
//		traverse();
//		descend(Html.ANCHOR);
//		touch();
//         
         
//         focus(tagContains(LABEL, "Client Legal Entity" ));
//         traverse();
         
//         focus(Modal.CONTAINER);
// 		 descend(text("Override D&B"));  // to <span> in modals
// 		 ascend();
// 		 traverse();
// 		 touch();
 		 
             
 		//Parq element =Parq.show(); 
         
//         focus(className("slds-card flowRuntimeForFlexipage"));
//         focus(text("Client Legal Entity"));
//         focus(className("slds-button slds-button_icon slds-input__icon slds-input__icon_right"));         
//         descend(tag("lightning-primitive-icon"));
//         descend();
         
//         focus(text("Legal Entity Billing Details"));
//         ascend();
//         ascend();
//         //descend();
//         focus(tagContains(LABEL, "Country" ));
//         traverse();
//         descend(tag("input"));
//         compose("United Kingdom");
//         focus(partialText("United Kingdom")).touch();
//         descend(css("data-key","close"));
//         touch();
         //collect(css("data-key","close"));
         
         //focus(css("data-key","close")).touch();
        
         
         //collect(text("Clear Selection"));
        
         //descend();
         //collect(text("Clear Selection"));
         //Parq element =Parq.show(); 
         //descend(tag("svg")).touch();
         
         //touch();
//         touchJS();
         //choose(Index.ListIndex.SECOND);
         //choose(SECOND);
         //Parq element =choose(Index.ListReference.HEAD);
         //Parq element =traverse();
         //touch();
         //descend();
         //cchoose(SECOND).touchJS();
         
         //focus(className("slds-combobox_container"));
         //Parq element =descend(tag("lightning-primitive-icon"));
         //descend();
         //Parq element =descend(tag("lightning-primitive-icon"));
         //descend();
         //Parq element =collect(text("Clear Selection"));
         
//         focus(className("slds-combobox_container"));
//         Parq element =descend(tag("title"));
//         //Parq element =collect(css("data-key","close"));
//         //choose(SECOND);
//         Parq.show();
         
       //origin(); 
       //focus(className("slds-combobox_container"));
          //collect(text("Clear Selection"));
          //descend();
//          collect(tag("span"));
//          Parq.show();
//          Parq element =choose(FIRST);
//         Parq.show();
       //Parq element =focus(text("AutoAPI Account yyooay"));
            
         //sfocus(text("Clear Selection"));
         //Parq element =focus(text("AutoAPI Account yyooay"));
         //touch();
         
//         origin();         
//         collect(text("Clear Selection"));
//         collect(Html.LIST_ITEM);
//         choose(FIRST).touchJS();
         //choose(Index.ListIndex.SECOND).touch();
         //Parq element = Parq.show();
         
         //Parq element =focus(text("Client Legal Entity"));
         
         //choose(Index.ListReference.HEAD);
         
         
         //Parq element =focus(text("Client Legal Entity"));
//         descend();
//         Parq element = focus(text("Clear Selection"));
//         touch();
         
//        focus(className("slds-form-element__control"));
//        //focus(Modal.CONTAINER);
//		descend(text("Country"));
//		Browser.scrollTo();
//		traverse();
//		descend();
//		descend();
//		descend();
//		descend();
//		pause(1);
//		touch();
//		ascend();
//		traverse();
//		collect(tag("lightning-base-combobox-item"));
//		Parq element =choose(txt("United Kingdom"));
//		touch();
 		 //traverse();
         //compose("London");
         
         //Parq.go("https://testfile--sitest.sandbox.lightning.force.com/lightning/r/Account/0013M00001LdCpCQAV/view");
    	 
    	 
    	 //List<WebElement> bakeries = Parq.getDriver().findElements(By.id("uif53"));
    	 
    	 
//    	 List<WebElement> td_collection=Parq.getDriver().findElements(By.tagName("SPAN")); 
//         System.out.println(td_collection.size());
//         for (WebElement webElement : td_collection) {
//             String name = webElement.getText();
//             System.out.println("<-------->*******<--------> " + name);
//         }


       
         //Parq element =Parq.show();
        
        
        //Parq element =
//       focus(className("n-w-menu-item style-system-header n-widget--status-none n-w-menu-item--with-submenu"));
//       descend();
//       Parq element =collect(tag("a"));
       
       //data-widget="MenuItem
       
//        Parq element =focus(css("role", "MenuItem"));
//        descend();
//        descend();
        //touchJS();
       //descend();
       //choose(Index.ListReference.TAIL).touchJS();
       //Parq.show();
       //Parq element =ascend();
       //Parq element =descend(css("role", "menubar"));
       //traverse();
       //descend();
//       descend();
//       descend();
//       descend();
       
       //collect(tag("SPAN"));
//       ascend();
//       descend();
//       Parq element =descend();
       //Parq element = descend(tag(org.page.parq.runner.support.Html.Tag.SPAN));
       //touchJS();
       //collect(Html.SPAN);
       //choose(Index.ListReference.HEAD);
       
       //Parq element =collect(tag("SPAN"));
       //Parq element =Parq.show();
        
//        String envName ="SB2";
//         List<WebElement> rolesRegion =getDriver().findElements(By.xpath("//div[@role='menuitem']//span"));
// 		Actions act = new Actions(getDriver());				
// 		act.moveToElement(getDriver().findElement(By.xpath("//div[@role='menuitem']//span"))).build().perform();
// 		Page.sleep(6);
// 		System.out.println("size is " +rolesRegion.size());
// 		for(int i=0;i<rolesRegion.size();i++) {
// 			WebElement roleElement = rolesRegion.get(i);
// 			String roleValue = roleElement.getText().trim();
// 			System.out.println("role value is " + roleValue);
// 			if (roleValue.equals(envName+"_testfile PLC")) {
// 				System.out.println("selected region "+envName+"_testfile PLC");
// 				roleElement.click();
// 				break;
// 			}
// 		}
// 		Parq element = focus(text("Page Finance Data Management UK Region")).touch();
 		
 		
 		
         
 		//Parq.show();
         
         ////button[@title='Edit Street']//lightning-primitive-icon
         
         //String field = "Health & Safety Risk";
        
    	 //WebElement checkBox = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'"+field+"')]//span[@class='slds-checkbox_faux'][1]"));
//    	 WebElement checkBox  = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'Health & Safety Risk')]/ancestor::lightning-input//input"));
//    	 JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
//         String checkBoxTicked = (String) js.executeScript("return window.getComputedStyle(arguments[0],'::after').getPropertyValue('content');", checkBox);
//         System.out.println("checkBoxTicked value is " + checkBoxTicked);  
//         Assert.assertTrue(checkBoxTicked.startsWith("\""));
//         Assert.assertTrue(checkBoxTicked.endsWith("\""));
         ////String content = (String) js.executeScript(checkBoxTicked, checkBox);
         ////System.out.println("content value is " + content);   
       ////If ticked - the value returns "", if unticked - the value returns none without double quotes
       
         
//         boolean healthsafeltyriskCheckTicked = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'Health & Safety Risk')]/ancestor::lightning-input//input[1]")).isSelected();
//         System.out.println("healthsafeltyriskchecked check box value is " + healthsafeltyriskCheckTicked);
//         Assert.assertTrue(healthsafeltyriskCheckTicked);

//         focus(text("Health & Safety Risk"));
         //Parq element =descend();
         //traverse();
         //checkBoxTicked value is ""
         
//         WebElement checkBox = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'"+field+"')]//span[@class='slds-checkbox_faux'][1]"));
// 	     String script = "return window.getComputedStyle(arguments[0],'::after').getPropertyValue('content')";
//         JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
//         String content = (String) js.executeScript(script, checkBox);
//         System.out.println("content value is " + content); 
         //Parq element =Parq.show();
         
//         WebElement checkBox = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'"+field+"')]//span[@class='slds-checkbox_faux'][1]"));
//  	             String script =  "return window.getComputedStyle(arguments[0],'::after').getPropertyValue('content')";
//  	           JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
//         String content = (String) js.executeScript(script);
//         System.out.println("content value is " + content); 
//   
//         Parq element =Parq.show();
         
//         var before = window.getComputedStyle(elem, ':before').getPropertyValue('content');
//         if(before && before!=="none"){//<-- (IE / FF fix) check it doesn't equal 'none'
//             //content: is defined but it could still be an empty string
//             alert("Before="+before);
//         } else {
//             //there is no :before content: defined at all
//         }
         
        //update Work schedule 
      
 	    

// 		Page.sleep(2);
// 		Parq element =focus(className("slds-combobox_container"));
// 		descend(tag("div"));
// 		collect(tag("lightning-base-combobox-item"));
 		
 		//descend(tag("lightning-base-combobox-item")).collect(Html.LIST_ITEM);		
// 		choose(txt("France")).touch();		
// 		Page.sleep(5);
 	    

       
         
//          collect(className("test-id__field-label-container slds-form-element__label"));
//          Parq.show();

   	  
//        List lstElmntLC=Parq.getDriver().(tag(findElements(By.xpath("(//*[(text()='Required Job Information' )])"));
//   		System.out.println("lstElmntLCÂ sizeÂ isÂ "+lstElmntLC.size());
//   		if(lstElmntLC.size()>0){
//   		  Assert.fail(" FE user is able to see new quick action component called \"Required Candidate Information\" ");
//   		  }else {
//   	      System.out.println("FE is not able to see new quick action component called \"Required Candidate Information");
//   		}
 	  
   	      
         
        
         
  		//click on street 
         //tag("button");
         //Parq element =focus(className("slds-form-element__control slds-grid itemBody"));
         //Parq element =focus(css("title", "Edit Street"));
         //Parq element =descend();
         
         //Parq element =focus(className("test-id__field-label-container slds-form-element__label"));
//        Parq element =descend(text("Street"));
// 		fetch(ElementData.TEXT);
// 		Parq.show();
 		
         
//         origin();
//         collect(css("title", "Edit street"));
//         Parq element =choose(Index.ListReference.HEAD);
//         touch();
         
//         Parq element =focus(text("Required Job Information"));
//         ascend();
//         Parq element =ascend();
         
 		
    
 		
 		
// 		focus(className("slds-card__body slds-card__body--inner"));
// 		Parq element =descend(text("Email"));
// 		fetch(ElementData.TEXT);
// 		contains("Email");
// 		
// 		//click on edit address 
// 		focus(css("title","Edit Address")).touchJS();
// 		
// 		Page.sleep(5);
// 		Browser.scrollTo(text("Other Aï»¿ctioï»¿ns"));
// 		Page.sleep(5);    
      
         
        

        
        //focus(text("AutoAPI Account zvpaoe")).touch();
 		
// 		Browser.scrollTo(text("Other Aï»¿ctioï»¿ns"));
// 		Page.sleep(5); 
        //Parq element = touch();
         
        //check email and address fields 
  
         
//	List lstElmnt=Parq.getDriver().findElements(By.xpath("(//flexipage-field[@data-field-id='RecordCAP_CC_Social_Security_Costs_cField1']//span[@class='test-id__field-valueÂ slds-form-element__staticÂ slds-growÂ word-break-ie11Â is-read-only'])"));
//	System.out.println("lstElmntÂ sizeÂ isÂ "+lstElmnt.size());
//	if(lstElmnt.size()>0){
//	System.out.println("EditÂ AdditionalÂ PayrollÂ CostsÂ isÂ NotÂ editable");
//	  }else {
//	 Assert.fail("EditÂ AdditionalÂ PayrollÂ CostsÂ isÂ editable");
//	}
//        focus(text("Required Legal Entity Information"));
//        focus(text("Link a related record."));
//        Parq element = focus(text("Search accounts..."));
           
         //Parq element = focus(css("title","Search accounts..."));
 		
// 		List lstElmnt=Parq.getDriver().findElements(By.xpath("(//*[contains(concat(' ', normalize-space(@class), ' '), ' slds-card__body slds-card__body--inner ')]//*[(text()='Address' )])"));
// 		System.out.println("lstElmntÂ sizeÂ isÂ "+lstElmnt.size());
// 		if(lstElmnt.size()>0){
// 		  Assert.fail(" FS user is  able to see new quick action component called \"Required Candidate Information\" ");
// 		  }else {
// 	      System.out.println("EditÂ AdditionalÂ PayrollÂ CostsÂ isÂ NotÂ editable");
// 		}
         
		
		
		
		
		
 		
        
//         descend(tag("div"));  
         //Parq element =descend(tag("a"));
//         touch();
         //Parq element =touchJS();
         
         
         //Parq element =traverse();
       
//         Parq element = descend(tag("SPAN"));
//         String attachedtext = fetch(ElementData.TEXT);
//         System.out.println("Required Candidate Information is "+attachedtext);  
         //contains("Address");
         
        
//        focus(className("test-id__field-label"));
//        focus(text("Change Owner"));
//        ascend();
//        ascend();
//        ascend();
//        Parq element= traverse();
        //descend();
        //Parq element= traverse();
//   	    ascend();
//   	    ascend();
//   	    Parq element1=descend(tag("lightning-formatted-text"));
//   	    String actchangeowner = fetch(ElementData.TEXT);
//   	    System.out.println("actchangeowner is "+actchangeowner);  
         
         
//         WebElement xpathelement= Parq.getDriver().findElement(By.xpath("//*[@class='test-id__field-label'][contains(text(),'Change Owner')]//parent::div/following-sibling::div//lightning-formatted-text"));
//         String actchangeowner = xpathelement.getText();
//  	     System.out.println("actchangeowner is "+actchangeowner);   	 
        		 
       
  //Parq element=         focus(text("Cancellation Reason"));
//         focus(text("Yes"));    
//         touchJS();
//         pause(3);
//         focus(text("Cancellation Reason is Missing"));
//         focus(text("Cancellation Notes is Missing"));
//         focus(text("Change Owner is Missing"));         
//         focus(className("modal-container slds-modal__container"));
// 	    focus(text("Cancellation Reason"));
// 	    focus(className("slds-select"));
// 	    touch();
// 	    compose("Unavoidable - Amount renegotiated");
// 	    touch(); 
// 	    Page.sleep(2); 
//         focus(className("slds-modal__container"));
// 		descend(text("Cancellation Notes"));		
// 		traverse();
// 		descend();		
// 		clear();
// 		compose("test");
// 		Page.sleep(2);	
//         focus(className("modal-container slds-modal__container"));
// 		focus(className("slds-modal__content slds-p-around--medium"));	
// 	    descend(text("Change Owner"));
// 		ascend();
// 		ascend();		
// 		ascend();	
// 	    Page.sleep(2);
// 	    touch();
// 	    Page.sleep(2);
// 	    collect(tag("option"));
// 	    Parq.show();
// 	    choose(Index.ListIndex.SECOND).touch();
// 	    Page.sleep(2);
// 	    Browser.esc();	    
// 	    Modal.selectModalButton(Modal.Actions.YES);
//         pause(4);
//         Browser.refresh();
//         pause(10);
//         String expcancellationreason = "Unavoidable - Amount renegotiated";
//         focus(text("Cancellation Reason"));
//      	ascend();
//      	ascend();
//      	descend(tag("lightning-formatted-text"));
//      	String actcancellationreason = fetch(ElementData.TEXT);
//      	System.out.println("actcancellationreason is "+actcancellationreason);   	 
//      	Assert.assertEquals(expcancellationreason, actcancellationreason);     	  
//         String expcancellationnotes = "test";
//         focus(text("Cancellation notes"));
// 	    ascend();
// 	    ascend();
// 	    descend(tag("lightning-formatted-text"));
// 	    String actcancellationnotes = fetch(ElementData.TEXT);
// 	    System.out.println("actcancellationnotes is "+actcancellationnotes);   	 
// 	    Assert.assertEquals(expcancellationnotes, actcancellationnotes); 	 
//	    String expchangeowner = "Billing";
//	    focus(className("slds-form__item slds-no-space"));	    
//	    focus(text("Change Owner"));          
//   	    ascend();
//   	 ascend();
//   	    Parq element=ascend();
//   	    descend(tag("lightning-formatted-text"));
         
        
         
//        focus(className("slds-form__row"));
//        descend(text("Change Owner"));
//   	    ascend();
//   	    ascend();
//   	   
//   	    Parq element=descend(tag("lightning-formatted-text"));
//   	    String actchangeowner = fetch(ElementData.TEXT);
//   	    System.out.println("actchangeowner is "+actchangeowner);   	 
//   	    Assert.assertEquals(expchangeowner, actchangeowner);
   	  
//		
//		Parq element=touch();
         
         
//         focus(text("Cancellation Reason"));
//         focus(text("Yes"));
         //Parq element=touch();
       
         
      
//         focus(text("Yes"));
//         touch();
//         pause(3);
//         focus(text("Cancellation Reason is Missing"));
//         focus(text("Cancellation Notes is Missing"));
//         focus(text("Change Owner is Missing"));         
//        focus(className("modal-container slds-modal__container"));
//	    focus(text("Cancellation Reason"));
//	    focus(className("slds-select"));
//	    touch();
//	    compose("Unavoidable - Amount renegotiated");
//	    touch(); 
//	    Page.sleep(2); 
//        focus(className("slds-modal__container"));
//		descend(text("Cancellation Notes"));		
//		traverse();
//		descend();		
//		clear();
//		compose("test");
//		Page.sleep(2);	
//        focus(className("modal-container slds-modal__container"));
//		focus(className("slds-modal__content slds-p-around--medium"));	
//	    descend(text("Change Owner"));
//		ascend();
//		ascend();		
//		Parq element=ascend();	
//	    Page.sleep(2);
//	    touch();
//	    Page.sleep(2);
//	    collect(tag("option"));
//	    Parq.show();
//	    choose(Index.ListIndex.SECOND).touch();
//	    Page.sleep(2);
//	    Browser.esc();
//	    
//	    Modal.selectModalButton(Modal.Actions.YES);
//        pause(4);
//        Browser.refresh();
//        pause(4);
//        Form.verifyFieldValue("Cancellation Reason", "Unavoidable - Amount renegotiated");
//		Form.verifyFieldValue("Change notes", "Notes");
//		Form.verifyFieldValue("Change Owner", "Billing");
         
     	//main.java.customerconnect.po.ChangeOwner.activate();
//		modal.load();
//		main.java.customerconnect.po.ChangeOwner.change(userService.getConsultantName("FE1").getConsultantName());
//		modal.selectModalButton(Modal.Actions.CHANGE_OWNER);
		
//		String consultantName = userService.getConsultantName(CONSULTANT_FE_INT.getValue()).getConsultantName();
//	    System.out.println("consultantName is "+consultantName);
//	    
//	    focus(css("title","Change Owner")).touchJS();
//	    pause(2);
//		focus(className("changeOwnerContentBody"));
//		descend(Html.INPUT);
//		touch();
//		compose(consultantName);
//		pause(3);
//		clear();
//		pause(1);
//		compose(consultantName);
//		focus(className("lookup__list"));
//		pause(5);
//		Parq element=collect(tag(LIST_ITEM.getValue()));
//		pause(2);
//		Actions action = new Actions(Parq.getDriver());
//        action.sendKeys(Keys.DOWN);
//        action.sendKeys(Keys.RETURN);
//        action.build().perform();
        
 	
         
//         focus(className("slds-dropdown-trigger slds-dropdown-trigger_click slds-button_last overflow"));
//         descend(text("Show more actions"));
//         Parq element= touchJS();
//         Parq.show();
//         focus(text("Send SMS")).touch();
         
//         focus(css("data-field-id","RecordTR1_Start_Date_cField1"));
//         Parq element= descend(tag("lightning-formatted-text"));
//         String text = fetch(ElementData.TEXT);
//         System.out.println("TEXT IS + --->" + text);
         
//         focus(css("data-field-id","RecordTR1_Job_cField1"));           
//         descend(tag("a"));
//         Parq element=descend(tag("span"));
//         String text = fetch(ElementData.TEXT);
//	     System.out.println("TEXT IS + --->" + text);
         //Parq element= descend(tag("records-hoverablelink_hoverablelink"));
         //Parq element=  traverse();
         //Parq element= descend(tag("slot"));
         //descend();
         //Parq element= traverse();
         //Parq element= c
//         descend(tag("slds-grow flex-wrap-ie11"));
//	     Parq element= descend(tag("span"));
	     //String text = fetch(ElementData.TEXT);
	     //System.out.println("TEXT IS + --->" + text);
         
         //Parq element= descend();
         //Parq element= touchJS();
         //Parq.show();
         
         
         
         
//         Parq element= focus(className("slds-dropdown-trigger slds-dropdown-trigger_click slds-button_last overflow"));
//         ascend();
//         descend();
//         collect(tag("a"));
//         Parq.show();
         //Page.selectLinkByText("Edit");
         //Page.selectLinkText("Edit");
         //Parq element= touchJS();
         
         
//       	WebElement element2= Parq.getDriver().findElement(By.xpath("//div[@class='slds-input__icon-group slds-input__icon-group_right']"));
//	    JavascriptExecutor executor = (JavascriptExecutor) Parq.getDriver();
//	    executor.executeScript("arguments[0].click();", element2);
//	    pause(5); 
	    //Parq.getDriver().findElement(By.xpath("(//input[contains(@class,'slds-combobox__input slds-input')])[1]")).sendKeys("8:00");
    	//WebElement element3= Parq.getDriver().findElement(By.xpath("//input[@class='slds-media slds-listbox__option slds-media_center slds-media_small slds-listbox__option_plain']//span[contains(text(),'8:00')]"));
 		
	    //WebElement element3= Parq.getDriver().findElement(By.xpath("(//input[contains(@class,'slds-combobox__input slds-input')])[1]"));
	    
	    //WebElement element3= Parq.getDriver().findElement(By.xpath("//button[contains(@class,'slds-combobox__input')])[1]"));
	    
//	    Actions action=new Actions(Parq.getDriver());
//        action.moveToElement(element3);
//        action.click();
//        action.build().perform(); 
	    
//	    focus(className("slds-input__icon-group slds-input__icon-group_right"));        
//        ascend();
//        ascend();
//        ascend();
//        Page.sleep(2);
//        touch();
//        collect(tag("span"));               
//        Parq element= choose(txt("08:00")).touchJS();
//        Page.sleep(2);
//        Browser.esc();
//        Parq element=choose(Index.ListIndex.TENTH).touchJS();
        

         
        
//        focus(className("modal-container slds-modal__container"));
// 	    focus(text("Cancellation Reason"));
// 	    focus(className("slds-select"));
// 	    touch();
// 	    compose("Unavoidable - Amount renegotiated");
// 	    touch(); 
// 	    Page.sleep(2); 
//        focus(className("slds-modal__container"));
//		descend(text("Cancellation Notes"));		
//		traverse();
//		descend();		
//		clear();
//		compose("test");
//		Page.sleep(2);		
//		focus(className("slds-form-element__control slds-grow"));
// 	    focus(text("Change Owner"));
//		ascend();
//		ascend();
//		ascend();	
// 	    Page.sleep(2);
// 	    touch();
// 	    collect(tag("option"));
// 	    =choose(Index.ListIndex.THIRD).touchJS();
// 	    Page.sleep(2);
// 	    Browser.esc();
 	    
 	    
 	    
// 	    Page.sleep(2);
// 	    compose("Ops");
// 	    Page.sleep(2);
// 	    touch(); 
       
//       focus(className("slds-select"));
//       touch();
//        Page.sleep(2); 
//	   	descend(text("Unavoidable - Amount renegotiated"));  // to <span> in modals
//		ascend();
//		ascend();
//		//ascend();
//		=traverse();
//		Browser.enter();//         Modal.sldsInputVertical("Cancellation Notes", "Notes"); 
//         focus(className("slds-select"));
//         touch();
//         focus(text("Job cancelled"));
//         touch(); 
//         pause(1);        
//         focus(text("Yes"));
//         touch();

         // Modal.select(Modal.Actions.YES);
         // Modal.input(CancelFieldType.CANCELLATION_NOTES.getValue(), "Notes");        
         // Modal.dropdown(CancelFieldType.CANCELLATION_NOTES, 1);
         // Modal.select(Modal.Actions.YES);
         
//         focus(className("slds-button slds-button_brand"));
//         =touch();
         
//         focus(className("slds-card flowRuntimeForFlexipage"));
//         = collect(tag("p"));
//         choose(Index.ListIndex.SECOND);
         //focus(className("slds-rich-text-editor__output"));
              //=descend(tag("p"));
         //= traverse();
//         String text = fetch(ElementData.TEXT);
//         System.out.println(" TEXT is " + text);         
//         focus(className("flowruntimeBody flowruntimeBody__lwc slds-card__body slds-p-horizontal_small"));
//         descend();
//         =descend(tag("b"));
//         String text = fetch(ElementData.TEXT);
//         System.out.println(" TEXT is " + text);
//         contains("This placement cannot be submitted for Review. Please ensure all the required fields are populated and relevant compliance documents are in place.");
//         
//         
         //descend(tag("h1"));
         //String text = fetch(ElementData.TEXT);
         //= descend();
//         ascend();
//         ascend();
//         descend();
         //traverse();
         //=  descend(tag("h1"));
              //= traverse();
          //String text = fetch(ElementData.TEXT);
          //System.out.println("TEXT is --->" + text);
         
//         UpdateActions.select(UpdateActions.Action.RATES);
//         Page.sleep(2);
//         UpdateActions.next();
//         UpdateActions.select(UpdateActions.RatesChange.PAY_RATE_CHANGE);
//         Page.sleep(2);
//         UpdateActions.next();
//         UpdateActions.updatePayRate("650");
//         UpdateActions.payRateDateupdate(EFFECTIVE_FROM_BILL_RATE);
//         UpdateActions.commentUpdatePayRate();
         // =focus(text("Comments"));
//         Page.sleep(2);
//         UpdateActions.next();
//         UpdateActions.no();
//         UpdateActions.next();
//         Page.handleSpinner();
         
//         String YesterdayDate =DateUtils.getDate(DateUtils.When.YESTERDAY, DateUtils.DateFormat.FORWARD_SLASH);
//         System.out.println("YesterdayDate is " + YesterdayDate);
//         =touch();
                
         
//         focus(className("slds-form-element__label slds-rich-text-editor__output"));
//         ascend();
//         ascend();
//         descend();
//          =focus(text("Comments"));
         
//         focus(className("slds-form-element__label slds-rich-text-editor__output"));
//          =focus(text("Comments"));
         
         
//         ascend();
//         ascend();
//         ascend();
//          =descend(tag("lightning-input"));
//         touch();
//          =compose("Other");
         
         // =focus(text("Comments"));
//         touch();
// 	    focus(className("slds-input"));
// 	    touch();
// 	     =compose("Other");
         
         //lightning-formatted-rich-text[@class='slds-form-element__label slds-rich-text-editor__output']//span[contains(text(),'New Pay Rate')]
         //focus(text("Comments"));
//         focus(className("slds-form-element__label slds-rich-text-editor__output"));
//         ascend();
//         ascend();
//         descend(tag("span"));
//         descend();
//          =focus(text("Comments"));
         // =traverse();
         //descend(tag("span"));
//          =c 
         //compose("This is test");
//         descend();
//          =traverse();
//         descend();
//        focus(text("Comments"));         
	       // = compose("this is test");
         
         //tabs.select(ACTIVITY);
//         focus(className("slds-icon slds-icon_small"));
//         focus(css("data-key","task"));
//         focus(text("Subject"));
//         ascend();
//         traverse();
         
//         focus(className("slds-icon slds-icon_small"));
//         focus(css("data-key","task"));
//         touch();
//	       focus(text("Subject"));
//	       ascend();
//	        = compose("this is test");
	       
//	       focus(text("Due Date"));
//	       ascend();
//	       traverse();
//	       descend(Html.INPUT);
//	       compose(GeneralCommonFunctions.currentDate());         

//         ContactDetail.logCall();
//         perform(new JavascriptExecutionHandler("window.scrollBy(0,400)"));
//         tabs.action(Tabs.Action.SAVE);
//         Locator ThisMonth = text("This Month");
//         perform(new ScrollIntoViewHandler(ThisMonth)); 
//      
//         //Edit Client call log
//         BusinessDevelopment.edit();
//         BusinessDevelopment.setReminder();
//         BusinessDevelopment.setStatus(BusinessDevelopment.Status.OPEN);
//         modal.select(Modal.Actions.SAVE);
//         modal.unload(); 
         
         //Create Follow up task
//         BusinessDevelopment.createFollowupTask();
//         modal.sldsLoad();
//         modal.select(Modal.Actions.SAVE);
//         modal.unload(); 
         
         //Validate the toast
//         improvisedToast.validateMessage(TASK);
//          =touch();
  
         
         
         
         ////span[text()='Start Date']/parent::div/following-sibling::div//lightning-formatted-text
         
//         focus(text("Placement Information"));
//         focus(text("Start Date"));
         
//         focus(text("Due Date"));
//         ascend();
//         ascend();
//         = traverse();
         //=descend();
         //descend();
         //= traverse();
         //ascend();
//         = descend(tag("uir-field inputreadonly"));
//         String text = fetch(ElementData.TEXT);
//         System.out.println("TEXT IS*****************" + text);
         
         
         //focus(css( "title", "Start Date"));
         //ascend();
//         traverse();
//         =ascend();
         //String text = fetch(ElementData.TEXT);
       //System.out.println("TEXT IS*****************" + text);
         
         
//         focus(text("Sales Order Revenue Splits"));
//         touch();
//         focus(text("Show more actions"));
//         touchJS();
//         pause(2);
//         focus(text("Edit"));
//         touchJS();
//         pause(2);
//         focus(className("slds-form-element__control slds-grow"));
//         descend();
//         touch();
//         clear();
//         pause(5);
//         compose("0.05");
//         pause(2);
// 		  compose(Keys.TAB);
//         pause(2);
//         ModalSLDS.select(SAVE);
         
         
//         focus(text("Clear Selection"));
//          = touchJS();
//         String editFieldName = "Consultant";
//         String value ="QA AUTO UK FE DOM 1";
//         WebElement inputBox = Parq.getDriver().findElement(By.xpath("//div[contains(@class, 'isModal')]//*[contains(text(), '"+editFieldName+"')]//../following::input[1]"));
// 		inputBox.click();
// 		Page.sleep(5);
// 		inputBox.sendKeys(value);
//         Page.sleep(5);
//         Parq.getDriver().findElement(By.xpath("//div[contains(@class, 'isModal')]//*[contains(text(), '"+editFieldName+"')]/../..//*[@title='" + value + "']")).click();
       
         
         
//         focus(ERRORS_LIST);
//         collect(Html.LIST_ITEM);
//         choose(Index.ListIndex.FIRST);
//         Parq.show();
//         =contains("Sales Order has been submitted and cannot be modified.");
//         ModalSLDS.select(CANCEL);
       
         
//         origin();
//         focus(className(Page.Window.WINDOW_NORMAL.getValue()));
//         descend(main.java.customerconnect.po.Html.ARTICLE);
//         collect(main.java.customerconnect.po.Html.SPAN);
//         focus(text("Candidate Company VAT Number"));
//         ascend();
//         traverse();
//         ascend();
         //= descend(tag("lightning-formatted-text"));
//         contains("637426324");
         
//         focus(text("Sanctioned Status"));
//         ascend();
//         traverse();
//         descend(leaf());
//         =contains(org.page.parq.runner.support.Html.Tag.IMG);
         
//         focus(className("modal-container slds-modal__container"));
//         focus(text("Request Reject Reason"));
//         ascend();
//        = traverse();
//	     descend();
	     
         
//            focus(text("Reject"));
//            touch();            		
//	        focus(className("modal-container slds-modal__container"));
//	        focus(text("Request Reject Reason"));
//	        focus(className("slds-select"));
//	        touch();
//	        compose("Other");
//	        focus(text("Request Reject Reason Notes"));
//	        focus(className("slds-input"));
//	        touch();
//	        =compose("Other");
//	        focus(text("Next"));
//            touch(); 
         
         
//	        focus(className("modal-container slds-modal__container"));
//	        focus(text("Request Reject Reason Notes"));
//	        descend();
//	        touch();
////	        ascend();
////	        descend();
//	        //ascend(Html.INPUT);
//	        =compose("testing");
	        
	        //Modal.input("Request Reject Reason Notes", "Notes");
	        //focus(className("modal-container slds-modal__container"));
//	        focus(text("Request Reject Reason Notes"));
//	        descend();
	        //ascend();
//	        ascend(tag("input"));
//	        =compose("Other");
	       
	        
	       
//	        ascend();
//	        ascend();
//	        descend(tag("select"));
	        //=compose("Other");
	     
//	     = compose("Other");
	     
         
            
         //= traverse();
         //Parq.show();
         //descend(main.java.customerconnect.po.Html.LIGHTENING_TEXT);
         // =contains("637426324");
     
   //'Account Histories
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/Histories/view
   //Notes
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/AttachedContentNotes/view
   //File
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/AttachedContentDocuments/view
   //Agreement_Applies_To
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/Agreement_Applies_To__r/view
   //Agreements         
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/TR1__Agreements__r/view
   //NetSuite_Legal_Entities
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/NetSuite_Legal_Entities__r/view
   //Projects
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/Projects__r/view
   //Accountteam Member
   //https://testfile--uat.lightning.force.com/lightning/r/Account/0013L00000KExO9QAL/related/AccountTeamMembers/view
     
         
//         
//         try {             
//             focus(className("slds-table"));
//             descend(tag("tbody"));
//        	 element=descend(tag(ANCHOR)); 
//        	 String text = element.getWebElement().getText();
//        	 System.out.println("*************TEXT IS  "+text);
// 		} catch (NoSuchElementException e) {
// 			System.out.println("text is  null");
// 		}
//         
//         System.out.println("execution continued");
         
         //System.out.println("*************TEXT IS  "+text);
         
//         text = text != null ? text.trim() : "" ;
//		if(text!=null && text !=""){
//			System.out.println("text is not null");
//			
//		}
         
         
//         if (text. ) {
// 			result = true;
// 			System.out.println(salesOrder + " Sales Order status is " + status);
// 			break;
// 		}else {
// 			System.out.println(salesOrder + " Sales Order status is not " + status + " Retry.."+ ++count);
// 			Page.sleep(10);
// 			Browser.refresh();
// 		}
// 	}
//     assertTrue(result,"true");
         
         
//         focus(text(applicantDetails.getPhone()));
//         focus(text(applicantDetails.getFirstName() + " " + applicantDetails.getLastName()));               
         
          
         //Parq.expect(text("This is beyond the second extension, please change your contract details if required."));
         //https://testfile--uat.lightning.force.com/lightning/r/CAP_CC_Rate__c/a7G3L0000001ncuUAA/view
 //------------------------------------------------------------------------------------------------------------------------------------------- 
         //AutoAPI Client tcnmhm , frauto01032022_2006214223@example.com         
         //CallListDetails.persistentLookUpAndSelect("Recipients", "AutoAPI Client tcnmhm", "frauto01032022_2006214223@example.com", 5);
         //origin();
//         boolean elementFound=false;
//         focus(className("slds-listbox__item"));
//         ascend();
//         Parq ListItems =collect(tag("li"));
//         String clientsLists =ListItems.getWebElement().getText().toString();         
//         String strClientContacts[] = clientsLists.split("[\\r\\n]+");         
//             
//         for (int j=0; j < strClientContacts.length; j=j+1) {         	 
//        	 String stringvalue = strClientContacts[j].trim();        	 
//        	 if (stringvalue.equals("AutoAPI Client xzaqir")){ 
//        		 elementFound= true;        		 
//        	 }           	 
//         }
//       
//         if (elementFound == false) {
//        	 CallListDetails.persistentLookUpAndSelect("Recipients", "AutoAPI Client xzaqir", "frauto01032022_2006356258@example.com", 5);
//         }
       ////*[(text()='Uploading Qualification' )]/../../..//following-sibling::*[1]//textarea
       //label[contains(text(),'Person Status')]/following-sibling::*[1]//*[1]//*[1]//*[1]//*[1]/../following-sibling::*[1]//lightning-base-combobox-item

     
//         focus(tagContains(LABEL, "Person Status" ));
//         touchJS();  
//          traverse();
//         descend();
//         descend();
//         descend();
//         descend();
//         pause(1);
//         ascend();
//         traverse();
//         collect(tag("lightning-base-combobox-item"));
//         Parq.show();
//          = choose(Index.ListIndex.THIRD);
         
         
       //label[contains(text(),'Person Status')]/../../../../../../..//following-sibling::div[@role='listbox']
         //focus(tagContains(LABEL, "Person Status" ));
         
         //Parq.frame();
         // =focus(className("tooltipstered"));
      	
 //-------------------------------------------------------------------------------------------------------------------------------------------  
         // =touchJS();
  		 WebElement xpathEle = element.getWebElement();
 		 System.out.println("XPATH Collection is " + xpathEle);
 		 System.out.println("ELEMENT collection is " + element.show());
		 String xpath =xpathEle.toString();
  		 
 		String segments[] = xpath.split("xpath: ");
 		String output = "";		
 		String stringvalue ="";		
 		int indexstart = 0;
 		int indexend= 0;
 		System.out.println("Total XPATH collection is " + segments.length);
 		for (int i=1; i < segments.length; i=i+1) {     // iterate and print odds only	
 			stringvalue = segments[i].replaceAll("-> ","").trim();
 			System.out.println("stringvalue is " + stringvalue);
 			System.out.println("stringvalue is " + stringvalue.length());			
 			System.out.println("stringvalue is " + stringvalue.substring(0, 1));
 			
 			//Removing dot in the beginning of each generated xpath			
 				if (stringvalue.substring(0, 1).matches("[.]{1}")) {				
 				    indexstart = 1;	
 				   }else {
 					indexstart = 0;	
 				}			
 				if (stringvalue.contains("following-sibling")) {				
 					stringvalue = "/" + stringvalue + "]";
 				}
 				if (stringvalue.contains("preceding-sibling")) {				
 					stringvalue = "/" + stringvalue + "]";
 				}
 				if (stringvalue.contains("selec")) {				
 					stringvalue = stringvalue + "t";
 				}
 				if (stringvalue.contains("inpu")) {				
 					stringvalue = stringvalue + "t";
 				}
 
 			switch (stringvalue) {
 			case "..]]":		
 				output += "/.";
 			case "..]":		
 				output += "/.";	
 				
 		   default:				
 				output += stringvalue.substring(indexstart, stringvalue.length() - 2);				
 			}	
 			
 			System.out.println("print output is " + output);
 		}
 		System.out.println("output is " + output);
    }
     
     
   //------------------------------------------------------------------------------------------------------------------------------------------- 

    private static void show() {
		// TODO Auto-generated method stub
		
	}

	private static URL getEndpoint(WebDriver driver) throws NoSuchFieldException, IllegalAccessException {
        // get RemoteWebDriver type
        Class remoteWebDriver = getRemoteWebDriver(driver.getClass());

        // get this instance executor > get this instance internalExecutor
        Field executorField = remoteWebDriver.getDeclaredField("executor");
        executorField.setAccessible(true);
        CommandExecutor executor = (CommandExecutor) executorField.get(driver);

        // get URL
        Field endpointField = getCommandExecutor(executor.getClass()).getDeclaredField("remoteServer");
        endpointField.setAccessible(true);

        // result
        return (URL) endpointField.get(executor);
    }

    private static Class getRemoteWebDriver(Class type) {
        // if not a remote web driver, return the type used for the call
        if (!RemoteWebDriver.class.isAssignableFrom(type)) {
            return type;
        }

        // iterate until gets the RemoteWebDriver type
        while (type != RemoteWebDriver.class) {
            type = type.getSuperclass();
        }

        // gets RemoteWebDriver to use for extracting internal information
        return type;
    }

    private static Class getCommandExecutor(Class type) {
        // if not a remote web driver, return the type used for the call
        if (!HttpCommandExecutor.class.isAssignableFrom(type)) {
            return type;
        }

        // iterate until gets the RemoteWebDriver type
        while (type != HttpCommandExecutor.class) {
            type = type.getSuperclass();
        }

        // gets RemoteWebDriver to use for extracting internal information
        return type;
    }
    public static RemoteWebDriver createDriverFromSession(final SessionId sessionId, URL command_executor){
        CommandExecutor executor = new HttpCommandExecutor(command_executor) {

            @Override
            public Response execute(Command command) throws IOException {
                Response response = null;
                if (command.getName() == "newSession") {
                    response = new Response();
                    response.setSessionId(sessionId.toString());
                    response.setStatus(0);
                    response.setValue(Collections.<String, String>emptyMap());

                    try {
                        Field commandCodec = null;
                        commandCodec = this.getClass().getSuperclass().getDeclaredField("commandCodec");
                        commandCodec.setAccessible(true);
                        commandCodec.set(this, new W3CHttpCommandCodec());

                        Field responseCodec = null;
                        responseCodec = this.getClass().getSuperclass().getDeclaredField("responseCodec");
                        responseCodec.setAccessible(true);
                        responseCodec.set(this, new W3CHttpResponseCodec());
                    } catch (NoSuchFieldException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                } else {
                    response = super.execute(command);
                }
                return response;
            }
        };

        return new RemoteWebDriver(executor, new DesiredCapabilities());
    }
}

