package main.zstandalone;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Command;
import org.openqa.selenium.remote.CommandExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.remote.Response;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.remote.codec.w3c.W3CHttpCommandCodec;
import org.openqa.selenium.remote.codec.w3c.W3CHttpResponseCodec;
import org.openqa.selenium.remote.http.JsonHttpCommandCodec;
import org.openqa.selenium.remote.http.JsonHttpResponseCodec;
import main.java.mongo.ccobjects.Environment;
import main.java.mongo.ccobjects.User;
import main.java.netsuite.po.SalesOrderBilling;

import static main.java.mongo.services.MongoServices.environmentService;
import static main.java.mongo.services.MongoServices.userService;
import static org.xxxx.parq.runner.support.Html.Tag.*;
import static java.lang.String.format;
import static main.java.broadbean.po.CustomerConnectBroadBeanForm.Button.LOGIN_TO_BROADBEAN;
import static main.java.broadbean.po.CustomerConnectBroadBeanForm.Button.POST_TO_BROADBEAN;
import static main.java.customerconnect.handler.QuickLinksHandler.Type.JOB_LEADS;
import static main.java.customerconnect.po.Contact.Field.BILLING_CONTACT;
import static main.java.customerconnect.po.Tabs.Type.RELATED;
import static main.java.customerconnect.po.Toast.Type.COMPLIANCE_COMPLIANT_STATUS;
import static main.java.customerconnect.po.xp.FasterxxxxAction.Type.NEW;
import static main.java.customerconnect.po.xp.fluentwait.ConditionalWait.getVisibleWebElement;
import static main.java.test.MRP.TempPlacement.UpdateActions.Date.START_FR;
import static main.java.test.MRP.TempPlacement.UpdateActions.Date.END_FR;
import static main.java.test.Utilities.GeneralCommonFunctions.getResourcePath;
import static main.java.test.journeys.JobSplit.Consultant.CONSULTANT_DOM_FE1;
import static org.xxxx.parq.runner.run.Parq.ascend;
import static org.xxxx.parq.runner.run.Parq.choose;
import static org.xxxx.parq.runner.run.Parq.className;
import static org.xxxx.parq.runner.run.Parq.clear;
import static org.xxxx.parq.runner.run.Parq.collect;
import static org.xxxx.parq.runner.run.Parq.compose;
import static org.xxxx.parq.runner.run.Parq.contains;
import static org.xxxx.parq.runner.run.Parq.css;
import static org.xxxx.parq.runner.run.Parq.descend;
import static org.xxxx.parq.runner.run.Parq.enc;
import static org.xxxx.parq.runner.run.Parq.fetch;
import static org.xxxx.parq.runner.run.Parq.focus;
import static org.xxxx.parq.runner.run.Parq.frame;
import static org.xxxx.parq.runner.run.Parq.getDriver;
import static org.xxxx.parq.runner.run.Parq.id;
import static org.xxxx.parq.runner.run.Parq.leaf;
import static org.xxxx.parq.runner.run.Parq.linkText;
import static org.xxxx.parq.runner.run.Parq.name;
import static org.xxxx.parq.runner.run.Parq.origin;
import static org.xxxx.parq.runner.run.Parq.partialText;
import static org.xxxx.parq.runner.run.Parq.pause;
import static org.xxxx.parq.runner.run.Parq.perform;
import static org.xxxx.parq.runner.run.Parq.present;
import static org.xxxx.parq.runner.run.Parq.range;
import static org.xxxx.parq.runner.run.Parq.select;
import static org.xxxx.parq.runner.run.Parq.show;
import static org.xxxx.parq.runner.run.Parq.tag;
import static org.xxxx.parq.runner.run.Parq.text;
import static org.xxxx.parq.runner.run.Parq.touch;
import static org.xxxx.parq.runner.run.Parq.touchJS;
import static org.xxxx.parq.runner.run.Parq.traverse;
import static org.xxxx.parq.runner.run.Parq.txt;
import static org.xxxx.parq.runner.run.Parq.val;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;
import static main.java.netsuite.po.SalesOrderBilling.*;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import main.java.broadbean.po.AdvertForm;
import main.java.broadbean.po.BroadBean;
import main.java.broadbean.po.CustomerConnectBroadBeanForm;
import main.java.broadbean.po.JobAdvert;
import main.java.broadbean.po.Language;
import main.java.broadbean.po.ManageAdverts;
import main.java.broadbean.po.Responses;
import main.java.customerconnect.handler.CVUpdateHandler;
import main.java.customerconnect.handler.CandidateStatusHandler;
import main.java.customerconnect.handler.MouseHoverAndClickHandler;
import main.java.customerconnect.handler.QuickLinksHandler;
import main.java.customerconnect.po.*;
import main.java.customerconnect.po.xp.CallListDetails;
import main.java.customerconnect.po.xp.CandidateDetails;
import main.java.customerconnect.po.xp.EmailCVToClient;
import main.java.customerconnect.po.xp.EntityHeaderSection;
import main.java.customerconnect.po.xp.FasterxxxxAction;
import main.java.customerconnect.po.xp.FasterQuickAdd;
import main.java.customerconnect.po.xp.FasterShortlist;
import main.java.customerconnect.po.xp.FasterTabs;
import main.java.customerconnect.po.xp.ImprovisedToast;
import main.java.customerconnect.po.xp.NewJobBoardApplication;
import main.java.data.customerconnect.api.HTTP.HttpAPIConnect;
import main.java.data.customerconnect.api.lib.APILibrary;
import main.java.data.customerconnect.api.services.RateAPIService;
import main.java.goldenqa.po.ApplicantDetails;
import main.java.goldenqa.po.BroadBeanSubmission;
import main.java.goldenqa.po.GeneralSubmission;
import main.java.test.CCQATest.CCUILibrary;
import main.java.test.CCQATest.NSLibrary;
import main.java.test.EnvConfig.BaseClass;
import main.java.test.EnvConfig.VMArgs;
//import main.java.test.MRP.Compliance.ComplianceLibrary;
import main.java.test.MRP.TempPlacement.TPLibrary;
import main.java.test.MRP.TempPlacement.UpdateActions;
import main.java.test.Utilities.DateUtils;
//import main.java.test.MRP.DataSharing.DS_Accounts;
import main.java.test.journeys.FasterxxxxTable;
import main.java.test.journeys.SalesOrder;
import main.java.users.CCUser;
import main.java.users.Country;
import main.zstandalone.LocalExecutor;

import org.xxxx.parq.runner.run.Parq;
import org.xxxx.parq.runner.run.ParqException;
import org.xxxx.parq.runner.search.Locator;
import org.xxxx.parq.runner.support.ElementData;
import org.xxxx.parq.runner.support.Html;
import org.xxxx.parq.runner.support.Index;
import org.testng.Assert;
import static org.xxxx.parq.runner.support.Index.ListReference.TAIL;
import static main.java.customerconnect.po.NetSuiteLegalEntityHistory.Status.CHECK_IS_VALID;
import static main.java.customerconnect.po.NetSuiteLegalEntityHistory.Status.SUCCESS;
import static main.java.customerconnect.handler.QuickLinksHandler.Type.NETSUITE_LEGAL_ENTITIES;
import static main.java.customerconnect.po.NetSuiteLegalEntityHistory.Status.SUBMIT_NEW_NSL;
import static main.java.test.journeys.JobSplit.Consultant.CONSULTANT;



//-Dserver=UAT -Dcountry=FR -Dxxxxdiv=PP
//https://testfile--uat.lightning.force.com
//admin qagensysadmin@michaelxxxx.com.uat SFadmin!!2022
//uk.fe.auto.qatest@michaelxxxx.com.uat   London2022@@@
//fr.fe.auto.qatest@michaelxxxx.com.uat
//https://3719513-sb1.app.netsuite.com TS14_UK@Test.com Welcome2019
//Paris2021@@@@ uk.fe.auto.qatest@michaelxxxx.com.uat London2021@@@@
//https://testfile--preprod.my.salesforce.com/
//uk.fe.auto.qatest@michaelxxxx.com.ppe
//London2021!!!
//int total_frames1 = Parq.getDriver().findElements(By.tagName("iframe")).size();
//System.out.println("Total frames in application is "+ total_frames1);
//focus(id("username")).compose("fr.fe.auto.qatest@michaelxxxx.com.uat");  // VM UPDATE
//focus(id("password")).compose("Paris2021@@@");
//focus(LOGIN).touch();  
//focus(css("title", "Edit Candidate Company Name"));
//focus(text("Candidate Company Name"));
//descend(css("data-value", selection.getValue()));
//descend(text(field));
//Browser.scrollTo();focus(className("resultitems"));
//focus(name("CAP_CC_Expected_Fill_Month__c"));
//traverse();
//descend(tag(LIST_ITEM, 1 ));
//reverse();
//descend(tag(LIST_ITEM, 1 ));
//Browser.scrollTo(CV_MANAGER);
//pause(2);descend(Html.INPUT);
//Browser.xxxxUp();
//xxxx.sleep(3);
//try{
//  focus(partialText("Show All"));
//	pause(3);
//	touch();
//}catch (Exception e){
//  e.printStackTrace();
//}
//QuickLink.select(CANDIDATE_COMPLIANCE_CHECKLIST);
//Menu.select(Menu.Type.JOBS);
//xxxx.sleep(5);      String text = fetch(ElementData.TEXT);
//Search.searchAndSelectFromList(references.getJob());
//QuickLink.navigate(QuickLink.Type.JOB_SPLITS);
//focus(text("Email")); css("for", "edit-mp-privacy-policy");
//Browser.scrollTo();focus(LOCATION_HINT).collect(Html.LIST_ITEM).choose(Index.ListIndex.FIRST).touch();
//select((txt("25 - 30K")));compose(Keys.TAB);  focus(linkText( linkText ));
//origin();
//collect(className("slds-p-around--xx-small slds-text-align_center slds-size_2-of-12"));
//choose(Index.ListIndex.FIRST);//descend(Html.INPUT);d//touchJS();
//get text from dailog box  focus(className("slds-box"));descend();fetch(ElementData.TEXT);contains(errorMsg);

public class test {
      private static Country nationality;
      private static  Country workCountry;
      private static  Country residenceCountry;       
      protected static final Modal modal = new Modal();
      public static Country country = Country.getCountryFromCode(VMArgs.getCountry()); 
      private static final BroadBeanSubmission broadBeanSubmission = new BroadBeanSubmission();
      private static final String IDENTITY_DOCUMENTATION_DOCX = "COMPLIANCE_DOCUMENTS\\\\IdentityDocumentation.docx";
      private static String server = System.getProperty("server");
      protected static final ImprovisedToast improvisedToast = new ImprovisedToast();
      public static APILibrary apiLib = new APILibrary();
      public static final Locator SANCTIONED_STATUS= css("title", "Sanctioned Status");
      
     public static void main(String[] args) throws Exception {
                
                               
         GeneralSubmission generalSubmission = new GeneralSubmission();
         String CVPATH_FR_DOC = "CV\\CVFrench.docx";
         String CVPATH_FR_PDF = "CV\\CVFrench.pdf";
         ApplicantDetails applicantDetailsEnglishDoc = null;
         ApplicantDetails applicantDetailsCountrySpecificDoc = null;
         ApplicantDetails applicantDetailsCountrySpecificPDF = null;
         boolean editAccess;
         References refCan;
         References refClient;
         final int NUMBER_OF_CONTACT = 6;
         List<String> candidateList = new ArrayList<>();
         //List<String> clientList = new ArrayList<>();
         //List<String> clientListUrls = new ArrayList<>();
//         List<String> clientList = Arrays.asList("AutoAPI Client ykhzel", "AutoAPI Client uoleyv", "AutoAPI Client fbuynl", "AutoAPI Client dgrhir", "AutoAPI Client rsdcvn", "AutoAPI Client xjlejm");
//         List<String> clientListUrls = Arrays.asList("https://testfile--uat.my.salesforce.com/lightning/r/Contact/0033L00000KNzkNQAT/view", "https://testfile--uat.my.salesforce.com/lightning/r/Contact/0033L00000KNzViQAL/view", "https://testfile--uat.my.salesforce.com/lightning/r/Contact/0033L00000KNzkrQAD/view", "https://testfile--uat.my.salesforce.com/lightning/r/Contact/0033L00000KNzlBQAT/view", "https://testfile--uat.my.salesforce.com/lightning/r/Contact/0033L00000KNzDjQAL/view", "https://testfile--uat.my.salesforce.com/lightning/r/Contact/0033L00000KNzlaQAD/view");
//         String prefix = FormData.generateRandomAlphaString(6);
         
         //Fix complaince
         //https://testfile--uat.lightning.force.com/lightning/r/Contact/0033L00000KeVEbQAN/view
         URL url = new URL("http://localhost:49849");      
         SessionId session_id = new SessionId("a52672c9fce65d23670595faad7c9928");                                
         RemoteWebDriver driver2 = createDriverFromSession(session_id, url);   
         Parq.setDriver(driver2);         
         WebDriver driver;
         
         
         
         
         
         //perform(new CandidateCvHandler("Active", 240));
         
                   
         
//         focus(text("Cancellation Reason"));
//         focus(text("Yes"));    
//         touchJS();
//         pause(3);
//         focus(text("Cancellation Reason is Missing"));
//         focus(text("Cancellation Notes is Missing"));
//         focus(text("Change Owner is Missing"));         
//         focus(className("modal-container slds-modal__container"));
// 	    focus(text("Cancellation Reason"));
// 	    focus(className("slds-select"));
// 	    touch();
// 	    compose("Unavoidable - Amount renegotiated");
// 	    touch(); 
// 	    xxxx.sleep(2); 
//         focus(className("slds-modal__container"));
// 		descend(text("Cancellation Notes"));		
// 		traverse();
// 		descend();		
// 		clear();
// 		compose("test");
// 		xxxx.sleep(2);	
//         focus(className("modal-container slds-modal__container"));
// 		focus(className("slds-modal__content slds-p-around--medium"));	
// 	    descend(text("Change Owner"));
// 		ascend();
// 		ascend();		
// 		ascend();	
// 	    xxxx.sleep(2);
// 	    touch();
// 	    xxxx.sleep(2);
// 	    collect(tag("option"));
// 	    Parq.show();
// 	    choose(Index.ListIndex.SECOND).touch();
// 	    xxxx.sleep(2);
// 	    Browser.esc();	    
// 	    Modal.selectModalButton(Modal.Actions.YES);
//         pause(4);
//         Browser.refresh();
//         pause(10);
//         String expcancellationreason = "Unavoidable - Amount renegotiated";
//         focus(text("Cancellation Reason"));
//      	ascend();
//      	ascend();
//      	descend(tag("lightning-formatted-text"));
//      	String actcancellationreason = fetch(ElementData.TEXT);
//      	System.out.println("actcancellationreason is "+actcancellationreason);   	 
//      	Assert.assertEquals(expcancellationreason, actcancellationreason);     	  
//         String expcancellationnotes = "test";
//         focus(text("Cancellation notes"));
// 	    ascend();
// 	    ascend();
// 	    descend(tag("lightning-formatted-text"));
// 	    String actcancellationnotes = fetch(ElementData.TEXT);
// 	    System.out.println("actcancellationnotes is "+actcancellationnotes);   	 
// 	    Assert.assertEquals(expcancellationnotes, actcancellationnotes); 	 
//    	    String expchangeowner = "Billing";
//         focus(text("Change Owner"));
//   	    ascend();
//   	    ascend();
//   	    Parq element1=descend(tag("lightning-formatted-text"));
//   	    String actchangeowner = fetch(ElementData.TEXT);
//   	    System.out.println("actchangeowner is "+actchangeowner);   	 
//   	    Assert.assertEquals(expchangeowner, actchangeowner);
    
      	
     	
//     	 JavascriptExecutor js = (JavascriptExecutor)Parq.getDriver();                
//         WebElement element = Parq.getDriver().findElement(By.xpath("//tr/td[10]/div[@class='listinlinefocusedrowcell']"));
//         js.executeScript("arguments[0].click();",element);     			       
//         Parq.getDriver().findElement(By.name("class_display")).click();
//         Parq.getDriver().findElement(By.name("class_display")).sendKeys("BT");
//         Parq.getDriver().findElement(By.name("class_display")).sendKeys(Keys.TAB);
         
         
//     	JavascriptExecutor jstest = (JavascriptExecutor) driver;
//		jstest.executeScript("document.getElementsByClassName('listinlinefocusedrowcell')['"+intIndex+"'].click();"); 	
//		//this.xxxxDown();		
//
//		TimeUnit.SECONDS.sleep(2);        			       
//		driver.findElement(By.name("class_display")).click();
//		TimeUnit.SECONDS.sleep(2);
//		driver.findElement(By.name("class_display")).sendKeys("BT");
//		TimeUnit.SECONDS.sleep(5);
//		driver.findElement(By.name("class_display")).sendKeys(Keys.TAB);
//		TimeUnit.SECONDS.sleep(5);	
         
         
//         focus(text("Due Date"));
//         ascend();
//         ascend();
//         traverse();
//         contains(DateUtils.getDate(DateUtils.When.FUTYRE_TWO_DAYS, DateUtils.DateFormat.FORWARD_SLASH_NS));
         
         //TPLibrary.updateContractExtension_FR();
         
//         focus(css("title","Contract Extension"));
//         descend();
//         traverse();
//         focus(text("Next"));
//         touch();
         
         
//           String newplacemnet=Parq.getDriver().findElement(By.xpath("//span[text()='Start Date']/parent::div/following-sibling::div/descendant::lightning-formatted-text[1]")).getText();
//           System.out.println("newplacemnet is "+newplacemnet);
         
//         UpdateActions.select(UpdateActions.Action.DURATION);
//         xxxx.sleep(2);
//         UpdateActions.next();
//         UpdateActions.select(UpdateActions.DurationChange.CONTRACT_EXTENSION);
//         xxxx.sleep(2);
//         UpdateActions.next();
//         UpdateActions.updateStartDateFR(START_FR);
//         UpdateActions.updateEndDateFR(END_FR);
         
         
//       focus(css( "title", "Start Date"));
//       ascend();
//       traverse();
       //descend(leaf());
//       String text = fetch(ElementData.TEXT);
//       System.out.println("text is "+text);
//         
         
         
//         focus(text("Assigned To"));
//         //traverse();
//         ascend();
//         traverse();
//         descend(leaf());
//       String text = fetch(ElementData.TEXT);
//       System.out.println("TEXT IS " + text);
         
//         focus(text("Task Information"));
//         //ascend(tag("records-record-layout-event-broker"));
//         descend(tag(org.xxxx.parq.runner.support.Html.Tag.SPAN, "Assigned To" ));
//         ascend();
//         traverse();
//         descend(leaf());
//         String text = fetch(ElementData.TEXT);
//         System.out.println("TEXT IS " + text);
         
//         String consultantName = userService.getConsultantName(CONSULTANT.getValue()).getConsultantName();
//         System.out.println("consultantName is "+consultantName);
//         focus(css("title",value));
//         contains(value);
         
//         focus(text("Email: Candidate Marketed Complete your registration"));
//         touchJS();
         
         //EntityHeaderSection.verifyCandidateStage("QA AUTO UK FE MAIN");
         
         //String title=Parq.getDriver().getTitle();
         //System.out.println("Title is " + title);
         
//         focus(text("Reject"));
//         touch();
         //SalesOrder.reject("Other");
         
         
         //final String rejectInputFieldLocator = ".//div[contains(@class, 'slds-modal')]//*[text() = 'Request Reject Reason']/ancestor::*[contains(@class, 'input')]";
         
//         WebElement createdBy = Parq.getDriver().findElement(By.xpath(".//div[contains(@class, 'slds-modal')]//*[text() = 'Request Reject Reason']/ancestor::*[contains(@class, 'input')]//input"));
//  		
//         createdBy.sendKeys("Other");
         
         
//         focus(className("modal-container slds-modal__container"));
//         focus(text("Request Reject Reason"));
         //ascend();
//         descend(Html.SELECT);
//         compose("Other");
        
         //fasterxxxxAction.select(REJECT_SO);
         //getVisibleWebElement(rejectInputFieldLocator).sendKeys("Other");
         //modalSLDS.select(ModalSLDS.Action.NEXT);
         
         
         //EmailCVToClient.switchToParentTab();
         
// 	   WebElement invoiceRow = Parq.getDriver().findElement(By.className("checkbox_ck"));
//	   invoiceRow.click();
//	   invoiceRow.click();
////	   
//	   focus(id("secondarysubmitter")); 
//   
//	         
//        Set<String> handles = Parq.getDriver().getWindowHandles();
// 		Iterator<String> it = handles.iterator();
// 		String parentWindowId = it.next();
// 		System.out.println("parent window id : " + parentWindowId);
// 		
// 		Parq.getDriver().switchTo().window(parentWindowId);
//		//if without switching, you are interacting with parent window:
//		//it will throw: NoSuchWindowException: no such window: target window already closed
//		String parentWindowTitle = Parq.getDriver().getTitle();
//		System.out.println("parent window title : " + parentWindowTitle);
         
         
//       INEB00041903
//       TS08_BR@Test.com
//       Welcome2019
       //SalesOrderBilling.acceptInvoicePayment(); 
//   	   WebElement invoiceRow = Parq.getDriver().findElement(By.className("checkbox_ck"));
//       invoiceRow.click();
//       invoiceRow.click();
//       Browser.switchWindow(Index.WindowIndex.NEXT);
//       focus(text("Selecionar"));
//       touch();
//       focus(id("secondarybtn_adicionar"));
//       touch();
//       pause(5);
//       focus(id("secondarysubmitter")); 
//       touch();
         
         //Browser.refresh();
         //xxxx.sleep(2);
         //Form.verifyField_TopSanctioned(SANCTIONED_STATUS,"/resource/CAP_CC_Client_Conditionally_Sanctioned");
         
         //https://testfile--uat.sandbox.lightning.force.com/lightning/r/CAP_CC_NS_Legal_Entity__c/a5V3L0000005OfPUAU/related/Histories/view
         //https://testfile--uat.sandbox.lightning.force.com/lightning/r/CAP_CC_NS_Legal_Entity__c/a5V3L0000005OfUUAU/related/Histories/view   
			
			//NetSuiteLegalEntityHistory.waitFor(SUBMIT_NEW_NSL, SUCCESS);
		//	NetSuiteLegalEntityHistory.waitFor(CHECK_IS_VALID, SUCCESS);

         
         //TPLibrary.updatePlacementFE(NewTempPlacement.PayType.PAYROLL);
         
//         
//         List lstElmnt=Parq.getDriver().findElements(By.xpath("(//flexixxxx-field[@data-field-id='RecordCAP_CC_Social_Security_Costs_cField1']//span[@class='test-id__field-value slds-form-element__static slds-grow word-break-ie11 is-read-only'])")); 
//         System.out.println("lstElmnt size is "+lstElmnt.size());
//         if(lstElmnt.size()>0)         { 
//        	System.out.println("Edit Additional Payroll Costs is Not editable");
//           } 
//          else 
//         { 
//            Assert.fail("Edit Additional Payroll Costs is editable");
//         }
         
//         xxxx.sleep(2);
//         Tabs.select(RELATED);
//         xxxx.sleep(2);
//         xxxx.waitForText("Rate No");
//         xxxx.sleep(2);
//         xxxx.selectSpanByText("R-00011944");
//         try {
//           focus(css("title","Edit Additional Payroll Costs"));            
//         } catch (NoSuchElementException e) {
//        	 Assert.assertTrue("test is");
//         }
         //touch();
         
         //String createdBy=Parq.getDriver().findElement(By.xpath("(//span[@class='test-id__field-value slds-form-element__static slds-grow word-break-ie11 is-read-only'])")).getText();
// 		createdBy1=createdBy.split("\\,")[0];
// 		System.out.println("output is " +createdBy );
 		//System.out.println("output is " +createdBy );
 		
 		
         
         //boolean exists = Parq.getDriver().findElements(By.cssSelector("Edit Additional Payroll Costs")).size() != 0;
//         int existscount = Parq.getDriver().findElements(By.cssSelector("[@title='Edit Rate Type']")).size();
//         System.out.println("value is " + existscount);
        	
        
         
         
         
         
         //String newplacemnet=Parq.getDriver().findElement(By.xpath("//p[contains(text(),'An update is not available for this placement as it is not the latest. The latest placement is')]//a[2]")).getText();
         //System.out.println("newplacemnet is "+newplacemnet);
         
     //https://testfile--uat.lightning.force.com/lightning/r/TR1__Closing_Report__c/a0S3L000000KrdEUAS/view    
  
         
         
//         int counter = 0;
//         while(counter<=5)
//         {
//             try
//             {
//            	 String newplacement=Parq.getDriver().findElement(By.xpath("(//p[contains(text(),'An update is not available for this placement as it is not the latest. The latest placement is')]/../../..//p)[2]")).getText();
//                 System.out.println("newplacemnet is "+newplacement);
//                 salesForceID = strId.get("Id");
//                 break;
//             }
//             catch(org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
//             {
//                 System.err.println("Exception Handled");
//                 counter++;
//             }
//         }
         
//         String newplacemnet=Parq.getDriver().findElement(By.xpath("(//p[contains(text(),'An update is not available for this placement as it is not the latest. The latest placement is')]/../../..//p)[2]")).getText();
//         System.out.println("newplacemnet is "+newplacemnet);
         //References ref = apiLib.createJobPermanent(BooleanFlag.Status.API_URL_NAVIGATION_TRUE);
//         References ref =apiLib.createCandidate(BooleanFlag.Status.API_URL_NAVIGATION_TRUE);
//         System.out.println("CLIENT URL is " + ref.getCandidateURL());
           //RateAPIService clientID = RateAPIService.checkRecordAccess(CCUser.UserType.FINANCE.getValue(),Country.UNITED_KINGDOM.getCode(),"Contact/" + ref.getCandidateSFId());
//         System.out.println("CLIENT ID ACCESS VALUE is " + clientID.getSalesForceID());
         
         //RateAPIService clientID = RateAPIService.checkClientAccess(ref.getCandidateURL(), result);
//         RateAPIService clientID = RateAPIService.checkClientAccess(URL, result,"0033L00000QV3hIQAT");
//         System.out.println("CLIENT ID ACCESS VALUE is " + clientID.getSalesForceID());
         
         //String title=Parq.getDriver().getTitle();
//         final String CVPATH = "CV\\CVEnglish.txt";
//         final String CV_EXCEL_PATH = "CV\\CVExcel.xlsx";
//         final String SHORTCVPATH = "CV\\CVShortEnglish.txt";
//         ApplicantDetails applicantDetails = ApplicantDetails.createCandidate(CVPATH, country);
//         applicantDetails.setEmail(FormData.generateEmail());
//         System.out.println("Email is "+applicantDetails.getEmail());
//         DocumentParser.updateCV( SHORTCVPATH, CVUpdateHandler.Field.EMAIL, applicantDetails.getEmail() );
         
         //perform(new CandidateStatusHandler(Form.FormHeader.CANDIDATE_STATUS, Contact.CANDIDATE_STATUS.getValue(), "Active", 120));
         
//         String candidateStatus1 = Parq.getDriver().findElement(By.xpath("//div[@records-highlightsdetailsitem_highlightsdetailsitem]/p[@title= '"+CandidateStatusLabel+"']/following::img[1]")).getAttribute("alt");
//         System.out.println("candidateStatus1 is "+candidateStatus1);
         
         
//         System.out.println("title is "+title);
//         frame();         
//         Thread.sleep(5000);
//         focus(className("slds-combobox__form-element"));
//         descend(Html.INPUT);
//         touch();
//         Thread.sleep(5000);
//         Parq.getDriver().findElement(By.xpath("//div[@class='slds-combobox_container']//div[@class='slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right']")).sendKeys("AutoAPI Account bxxkrw - AutoAPI Job lcrcpq");
//         focus(partialText("AutoAPI Account bxxkrw - AutoAPI Job lcrcpq"));
//         touch();
         //JavascriptExecutor executor = (JavascriptExecutor) Parq.getDriver();
         //Parq.getDriver().findElement(By.xpath("//div[@class='slds-input slds-combobox__input has-custom-height']")).click();
        
//         String parent=Parq.getDriver().getWindowHandle();
//         Set<String> s=Parq.getDriver().getWindowHandles();
//		 List<String> lstNewWindow = new ArrayList<String>(s);
//		 Parq.getDriver().switchTo().window(lstNewWindow.get(0));
//	         frame();
//         Thread.sleep(5000);
         
//         WebElement element1 = Parq.getDriver().findElement(By.xpath("(//label[text()=' Job']//following::div[@class='slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click'][1])"));
//		 JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
//		 js.executeScript("arguments[0].click();", element1);
//		  WebElement findSummer = driver.findElement(By.xpath("//span[contains(@title,'Summer')][contains(text(), '20')]"));
//		  driver.executeScript("arguments[0].scrollIntoView();", findSummer);
//		  findSummer.click();
         //JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
         //js.executeScript("arguments[0].click();", Parq.getDriver().findElement(By.xpath("(//input[@class='slds-input slds-combobox__input has-custom-height'])")));
         //Thread.sleep(5000);
         //Parq.getDriver().findElement(By.xpath("//div[@class='slds-combobox_container']//div[@class='slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right']")).sendKeys("test");
         //Thread.sleep(3000);
         //js.executeScript("arguments[0].click();",Parq.getDriver().findElement(By.xpath("(//div[@class='slds-combobox__form-element slds-input-has-icon slds-input-has-icon_right'])[1]")));
     	//Thread.sleep(3000);
         
         
    	 //String candidateStatus1 = Parq.getDriver().findElement(By.xpath("//div[@records-highlightsdetailsitem_highlightsdetailsitem]/p[@title= 'Candidate Stage']/following::img[1]")).getAttribute("alt");
         //System.out.println("candidateStatus is "+candidateStatus1);
         
         //perform(new CandidateStageHandler(Contact.CANDIDATE_STAGE.getValue(), "Placed", 3));
         
         //TPLibrary.updatePlacement(NewTempPlacement.PayType.PAYROLL);
         //References references;
        //  references = apiLib.execute_Candidate_ActiveToPlaced();
         //System.out.println("job: " + references.getBatchResult());
//         references = apiLib.execute_Candidate_PlacedToPassive();
//         System.out.println("job: " + references.getBatchResult());
//         references = apiLib.execute_Candidate_PlacedToActive();
//         System.out.println("job: " + references.getBatchResult());
//         references = apiLib.execute_Candidate_ActiveToPassive();
//         System.out.println("job: " + references.getBatchResult());
//         references = apiLib.execute_Candidate_PlacedToPassive();
//         System.out.println("job: " + references.getBatchResult());
//         references = apiLib.execute_RecordToShareBatch();
//         System.out.println("job: " + references.getBatchResult());
//         references = apiLib.execute_PlacementStatusLiveBatch();
//         System.out.println("job: " + references.getBatchResult());
         
        
   		
// 		int count = 0, statusCount = 0 ;
//    	TPLibrary.waitAndRefresh(8);
//        boolean result = false;
//          
//        while(count < 20) {
//           String newPlacement=xxxx.getFullTextByPartialText("An update is not available for this placement");
//    	   String[] parts = newPlacement.split("The latest placement is ");
//    	   String adjPlacement=parts[1];
//    	   System.out.println("Adjustment placemnet is " +adjPlacement);
//          if (newPlacement.contains("An update is not available for this placement") ) {
//            result = true;
//            System.out.println("-Temp adjustment placement is created " );
//            break;
//        }else {
//            System.out.println("-Temp adjustment placement is not created "  + " Retry.."+ ++count);
//            Browser.refresh();
//            xxxx.sleep(20);			
//        	}
//        }
//        assertTrue(result,"true");
 		
 		
// 		String text=Parq.getDriver().findElement(By.xpath("//lightning-formatted-rich-text/span[contains(normalize-space(.),'An update')]/p/a")).getAttribute(("href"));
// 		System.out.println("link is "+ text);
         
//         WebElement Element = Parq.getDriver().findElement(By.xpath("//span[text()='Candidate Company VAT Number']/parent::div/following-sibling::div//lightning-formatted-text"));
//         System.out.println(Element.getText());
//         contains(Element.getText());         
//         Assert.assertEquals("637426324",Element.getText());
         

         //String contactReferrelID;
         //String UpdatedCandidateJson;
         
         //DataSharing.verifyDescendantRecords("test",Country.TURKEY.getCode(), CCUser.UserType.FEE_EARNER.getValue());
//         
//    	 UpdatedCandidateJson = HttpAPIConnect.updateContactJson("CAP_CC_Contact_Referral__c","CHANGECONTACTSFID","0033L00000LkPcEQAV");
//    	 System.out.println("UpdatedCandidateJson is " + UpdatedCandidateJson); 
//    	 
//		 contactReferrelID = HttpAPIConnect.postToSalesforce(CCUser.UserType.FEE_EARNER.getValue(),Country.UNITED_KINGDOM.getCode(), "CAP_CC_Contact_Referral__c",UpdatedCandidateJson);
//		 System.out.println("contactReferrelID is " + contactReferrelID);
//         User user = userService.getUserByRoleCountryAndServer(CCUser.UserType.FEE_EARNER.getValue(),Country.UNITED_KINGDOM.getCode(),VMArgs.getServer()); 
//         String strcontactIDReponse  = HttpAPIConnect.getSalesForce(CCUser.UserType.FEE_EARNER.getValue(),Country.NETHERLANDS.getCode(), "Contact","0033L00000LkQU1QAN","TR1__Owner_Name__c");
//         System.out.println("strcontactIDReponse is " + strcontactIDReponse);
// 	     assertEquals(strcontactIDReponse,user.getConsultantName());

         
         
         
//        String ContactID ="0033L00000LkFESQA3"; 
//        
//        String UpdatedKeyAccountJson = HttpAPIConnect.updateAccountJson("Account","KEYACCOUNTCHANGE","true");
//  	   System.out.println("UpdatedKeyAccountJson is " + UpdatedKeyAccountJson); 
//            
//      //UK BT      	
//      	editAccess = HttpAPIConnect.patchSalesforceRecord(CCUser.UserType.BT.getValue(), Country.UNITED_KINGDOM.getCode(),"Account","0013L00000KQzLPQA1" ,UpdatedKeyAccountJson);
//     	Assert.assertTrue(editAccess, "UK BT able to edit the KEY account");         
//            	
//        //NL BT 
//      	editAccess = HttpAPIConnect.patchSalesforceRecord(CCUser.UserType.BT.getValue(),Country.NETHERLANDS.getCode(), "Account","0013L00000KQzLPQA1" ,UpdatedKeyAccountJson);
//      	Assert.assertTrue(editAccess, "NL BT able to edit the KEY account"); 
//      	
//      	//MA BT 
//      	editAccess = HttpAPIConnect.patchSalesforceRecord(CCUser.UserType.BT.getValue(),Country.MOROCCO.getCode(), "Account","0013L00000KQzLPQA1" ,UpdatedKeyAccountJson);
//      	Assert.assertTrue(editAccess, "MA BT able to edit the KEY account");

        
//        UpdatedKeyAccountJson = HttpAPIConnect.updateAccountJson("Account","KEYACCOUNTCHANGE","true");
//		System.out.println("UpdatedKeyAccountJson is " + UpdatedKeyAccountJson);        
//     	boolean editAccess = HttpAPIConnect.patchSalesforceRecord(CCUser.UserType.FINANCE.getValue(), "Account",accountID ,UpdatedKeyAccountJson);
//     	Assert.assertTrue(editAccess, "Login xxxx title doesn't match");
        
//        UpdatedKeyAccountJson = HttpAPIConnect.updateAccountJson("Account","KEYACCOUNTCHANGE","true");
// 	    System.out.println("UpdatedKeyAccountJson is " + UpdatedKeyAccountJson);	
// 		
// 		boolean editAccess = HttpAPIConnect.patchSalesforceRecord(CCUser.UserType.FINANCE.getValue(), "GB", "Account",0033L00000LkDnlQAF ,UpdatedKeyAccountJson);
// 		Assert.assertTrue(editAccess, "Login xxxx title doesn't match");
         
         
//         String LinkedEntityId ="This is a LinkedEntityId1";  
//         String ContentDocumentId ="This is a ContentDocumentId1";  
         //String Strdata =HttpAPIConnect.updateJsonContentDocumentLink("ContentDocumentLink","ACCOUNTSFIDUPDATE",LinkedEntityId,"ACCOUNTCONTENTIDUPDATE",ContentDocumentId);
         //System.out.println("Strdata is " + Strdata);
         
            
//         focus(id(field.getValue())).touch().pause(1);
//         collect(tag("option"));
//         choose(index).touch();
   
         //System.out.println(title);
         ///../../../..
         
         //CandidateDetails.registerCandidate();
         
         ////*[contains(concat(' ', normalize-space(@class), ' '), ' modal-container ')]//*[(text()='Salary' )]/../../following-sibling::*[1]//input
//            focus(Modal.CONTAINER);
//			descend(text("Salary"));	
//			ascend();
//			ascend();
//			traverse();
			//Parq element = descend(Html.INPUT);
         
        ////*[contains(concat(' ', normalize-space(@class), ' '), ' modal-container ')]//*[(text()='Notice Period' )]/../../following-sibling::*[1]//select//option
//	        focus(Modal.CONTAINER);
//	 		descend(text("Notice Period"));  // to <span> in modals
//	 		ascend();
//	 		ascend();
//	 		traverse();
//	 		descend(tag("select"));
	 		//Parq element =collect(Html.OPTION);
         
//	        focus(Modal.CONTAINER);
//	 		descend(text("Meeting Notes"));  // to <span> in modals
//	 		ascend();
//	 		ascend();
         
//         focus(text("Uploading Qualification"));
//         ascend();
//         Parq element=ascend(); 
         //Parq element=ascend();
         //traverse();
         //Parq element =descend(tag(INPUT));
         //Parq element =traverse();
	 	 	
         
          
	 	//Parq element = ascend();
// 		WebElement xpathEle = element.getWebElement();
//		String xpath =xpathEle.toString();
//		System.out.println("element is " + xpath.toString());
//		String segments[] = xpath.split("xpath: ");
//		String output = "";		
//		String stringvalue ="";		
//		int indexstart = 0;
//		int indexend= 0;
//		for (int i=1; i < segments.length; i=i+1) {     // iterate and print odds only	
//			stringvalue = segments[i].replaceAll("-> ","").trim();
//			System.out.println("stringvalue is " + stringvalue);
//			System.out.println("stringvalue is " + stringvalue.length());			
//			System.out.println("stringvalue is " + stringvalue.substring(0, 1));
//			
//			//Removing dot in the beginning of each generated xpath			
//				if (stringvalue.substring(0, 1).matches("[.]{1}")) {				
//				    indexstart = 1;	
//				   }else {
//					indexstart = 0;	
//				}
//				//check last 2 characters	
//				System.out.println(stringvalue.substring(stringvalue.length()-2));
//				if (stringvalue.substring(stringvalue.length()-2).matches("[]]]")) {				
//				    indexend = 2;	
//				   }else {
//					indexend = 1;	
//				}	
//				
//				if (stringvalue.contains("following-sibling")) {				
//					stringvalue = "/" + stringvalue;
//				}
//				if (stringvalue.contains("preceding-sibling")) {				
//					stringvalue = "/" + stringvalue;
//				}
//
//			switch (stringvalue) {
//			case "..]]":		
//				output += "/.";
//		   default:				
//				output += stringvalue.substring(indexstart, stringvalue.length() - indexend);				
//			}	
//			
//			System.out.println("print output is " + output);
//		}
//		System.out.println("output is " + output);
		
		//String xpath2 =xpathEle.toString();
		
//		ascend();
//		ascend();
//		ascend();
//		ascend();		
//		traverse();
//		Parq.show();
//		descend(Html.INPUT);
////		clear();
//		compose("test");
         
//         xxxxAction.select(xxxxAction.Type.REGISTER_CANDIDATE);
//         Parq.pause(5);
//         Modal.load();         
//         String mobile = FormData.generateMobile();
//         Modal modal = new Modal();
//         modal.input_MandatoryFields(Contact.Field.MOBILE, mobile);
//         Modal.selectOptionsByValue_dropdown(Contact.CURRENT_INDUSTRY_LEVEL_1, "Business Services");
//         Modal.selectOptionsByValue_dropdown(Contact.CURRENT_INDUSTRY_LEVEL_2, "Accountancy Practices");
//         Modal.selectOptionsByValue_dropdown(Contact.CURRENTDEPARTMENT, "Accounting & Finance");
//         Modal.selectOptionsByValue_dropdown(Contact.CURRENT_ROLE_SPECIALISM, "Accountant");
         
         //CallListDetails.addContactToCallist("AutoAPI Client wzwgkc");
         
         //CallListDetails.addContactToCallist("AutoAPI Client wejifa");
  
         //confirm email marketing opt out
         //getDriver().navigate().refresh();
         //CallListDetails.selectAllContacts();
         //CallListDetails.showMoreAction();
//         CallListDetails.validateMarketingConfirmation(clientList.get(3));
//         CallListDetails.validateMarketingConfirmation(clientList.get(2));
//         CallListDetails.validateMarketingConfirmation(clientList.get(5));

         // If you can't see the email addresses of the clients whom you want to send email, there is a possibility that their marketing opt out option has been ticked in. please unselect and proceed.

         //send email
         //CallListDetails.emailToMembers();
//         improvisedToast.validateMessage(Toast.Type.EMAIL_SENT_SUCCESSFULLY);
//
//         //Confirm Message Status
//         CallListDetails.confirmMessageStatus();
         
         
         //https://testfile--uat.lightning.force.com/lightning/r/TR1__Call_List__c/a0H3L000002Jf7wUAC/view
         //AutoAPI Candidate nujkfx AutoAPI Candidate ppjwhr AutoAPI Candidate lodznt
         
//         String clientListURL = Parq.getDriver().getCurrentUrl();
//         System.out.println(clientListURL);
//         CallListDetails.selectAllContacts();
//         focus(text("Market Candidate"));
//         touch();
//        CallListDetails.persistentLookUpAndSelect(CallListDetails.SELECT_CANDIDATE, "Jack Red", "frauto25022022_0814280288@example.com", 8);
//         origin();      
//         collect(className("bottom-margin slds-form-element"));      
//         Parq.show();
         
         //focus(className("bottom-margin slds-form-element"));
         //descend();
         //origin();    
 	    //collect(className("slds-checkbox_faux"));
//         Parq.show();
//         collect(className("slds-form-element__label slds-assistive-text")); 
         //Parq.show();
         
//         focus(className("slds-p-around--xx-small slds-text-align_center slds-size_2-of-12"));
//         descend(Html.INPUT);
//         touchJS();
//         origin();
//         collect(className("slds-p-around--xx-small slds-text-align_center slds-size_2-of-12"));
//         choose(Index.ListIndex.FIRST);
//         descend(Html.INPUT);
//         touchJS();
//         choose(Index.ListIndex.SECOND);
//         descend(Html.INPUT);
//         touchJS();
//         Parq.show();
//         descend(Html.INPUT);
//         touchJS();
  
        
 
  
	
         
//     	ComplianceLibrary.auditComplianceDocuments("Right To Work", "Compliant");
//		improvisedToast.validateMessage(COMPLIANCE_COMPLIANT_STATUS);
//		pause(2);
//		ComplianceLibrary.verifyAuditStatus("Right To Work", "Audit Status : " + "Compliant");
         
//         //CC-24979 changes : Observe below fields will be displayed on compliance policy record:
//        	 //1.Applies To Perm Job 
//        	 //2.Applies To Payroll Temp Job 
//        	 //3.Applies To Own Company/Umbrella Temp Job
//         Environment environment = environmentService.get(server);         
//         Parq.go(environment.getUrl() + "/lightning/o/CAP_CC_Compliance_Policy__c/list?filterName=Recent");
//         xxxxAction.select(xxxxAction.Type.NEW);
//         focus(text("Applies To Perm Job"));
//         focus(text("Applies To Payroll Temp Job"));
//         focus(text("Applies To Own Company/Umbrella Temp Job"));        
//         
         
         // Observe below fields will not be displayed on compliance policy record:
         //1.Applies to Temp Job
         //2.Applies to FTC Job
         //3.Applies to Retained Job
//     	int count = 0, fieldCount = 0 ;
//    	xxxx.sleep(2);
//             
//        fieldCount =Parq.getDriver().findElements(By.xpath("//div[contains(@class, 'isModal')]//*[contains(text(), 'Applies to Temp Job')]")).size();
// 		System.out.println(" fieldCount count is   "+fieldCount);
// 		Assert.assertEquals(fieldCount, 0);
// 		
// 		fieldCount =Parq.getDriver().findElements(By.xpath("//div[contains(@class, 'isModal')]//*[contains(text(), 'Applies to FTC Job')]")).size();
// 		System.out.println(" status count is   "+fieldCount);
// 		Assert.assertEquals(fieldCount, 0);
// 		
// 		fieldCount =Parq.getDriver().findElements(By.xpath("//div[contains(@class, 'isModal')]//*[contains(text(), 'Applies to Retained Job')]")).size();
// 		System.out.println(" status count is   "+fieldCount);
// 		Assert.assertEquals(fieldCount, 0);
// 		//Navigtaing back to home xxxx
// 		
// 		Parq.go(environment.getUrl());
 		
// 		if (statusCount == 0 ) {
// 			result = true; 			
// 			break;
// 		}else {
// 			System.out.println(salesOrder + " Sales Order status is not " + status + " Retry.."+ ++count);
// 			xxxx.sleep(10);
// 			Browser.refresh();
// 		}
// 	
//     assertTrue(result,"true");
         
         //ComplianceLibrary.verifyCandidateComplianceAuditStatus("Placement Audit Status", "Compliant");
         
//         ComplianceLibrary.uploadComplianceTypeDocument(IDENTITY_DOCUMENTATION, IDENTITY_DOCUMENTATION_UPLOADED, IDENTITY_DOCUMENTATION_DOCX);
//         ComplianceLibrary.confirmComplianceUploaded("Identity Documentation","Uploaded");
//         //validate status of uploaded document
//         ComplianceLibrary.uploadComplianceTypeDocument(IDENTITY_DOCUMENTATION, IDENTITY_DOCUMENTATION_UPLOADED, IDENTITY_DOCUMENTATION_DOCX);
//         //ComplianceLibrary.verifyCandidateComplianceStatus(Ats.Stage.SHORTLIST);
         
         
         
                
         //applicantDetailsCountrySpecificDoc = ApplicantDetails.createCandidate(CVPATH_FR_DOC, country);
         //pause(3);
         //applicantDetailsCountrySpecificPDF = ApplicantDetails.createCandidate(CVPATH_FR_PDF, country);
        
         //start with browser one
//                    System.setProperty("webdriver.chrome.driver", "C:\\Automation\\drivers\\chromedriver\\chromedriver.exe");
//                    ChromeDriver driverOne = new ChromeDriver();
//                    driverOne.manage().window().maximize();
//                    // setup: get information to initialize driver two
//                    String sessionId = driverOne.getSessionId().toString();
//                    URL addressOfRemoteServer = getEndpoint(driverOne);
//                    Capabilities desiredCapabilities = driverOne.getCapabilities();
//                    CommandExecutor commandExecutor = new LocalExecutor(sessionId, addressOfRemoteServer, desiredCapabilities);
//                    System.out.println(sessionId);
//                    System.out.println(desiredCapabilities);
//                    URL url = ((HttpCommandExecutor) commandExecutor).getAddressOfRemoteServer();
//                    System.out.println(url);
//                    SessionId session_id = new SessionId(sessionId);                                
//                    RemoteWebDriver driver = createDriverFromSession(session_id, url);
//                    driver.get("https://testfile--uat.lightning.force.com/lightning/r/TR1__Job__c/a1C3L000001DYarUAG/view");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.michaelxxxx.fr/submit-your-cv");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.xxxxpersonnel.fr/submit-your-cv");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.xxxxpersonnel.co.uk/submit-your-cv");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.michaelxxxx.co.uk/submit-your-cv");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.xxxxpersonnel.fr/job-detail/ref/JN-022022-174151");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.michaelxxxx.fr/job-detail/ref/jn-022022-174168");
//                    driver.get("https://mxxxxauthd8:0_9G1*0%40Mp@goldenqa.michaelxxxx.co.uk/job-detail/autoapi-job-irrjos/ref/jn-022022-174204");
         //https://testfile--uat.lightning.force.com/lightning/r/TR1__Job__c/a1C3L000001DYarUAG/view
//                    generalSubmission.submitFR(applicantDetailsCountrySpecificDoc);                    
//                    String title=driver.getTitle();
//                    System.out.println(title);
         //https://trailhead.salesforce.com/trailblazer-community/feed/0D54S00000DbzTKSAZ
////                
                //Run on existing browser(comment above before running and copy url and sessionid)
                    
//                  WebElement checkBox  = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'PSA Active')]//span[@class='slds-checkbox_faux'][1]"));
//                  JavascriptExecutor js = (JavascriptExecutor) Parq.getDriver();
//                  String checkBoxTicked = (String) js.executeScript("return window.getComputedStyle(arguments[0],'::after').getPropertyValue('content');", checkBox);
//                  System.out.println("checkBoxTicked value is " + checkBoxTicked);
//                  Assert.assertTrue(checkBoxTicked.startsWith("\""));
//                  Assert.assertTrue(checkBoxTicked.endsWith("\""));
                  //Assert.assertTrue(checkBoxTicked.equals(""));
                  
                  //Assert.assertTrue( checkBoxTicked.equals("") ? true:false);
                  //Assert.assertEquals (checkBoxTicked,"");
              	//Assert.assertTrue (checkBoxTicked.contains(""));
//                  checkBoxTicked.startsWith("\"");
//                  checkBoxTicked.endsWith("\"");
                  
                 // Assert.assertEquals("",checkBoxTicked );
              	//Assert.assertTrue (checkBoxTicked.equals(""));
//                  WebElement checkBoxNotTicked  = Parq.getDriver().findElement(By.xpath("//div[contains(@class,'slds-form-element')]//label[contains(.,'PSA Active')]//span[@class='slds-checkbox_faux'][1]"));
//                  JavascriptExecutor js1 = (JavascriptExecutor) Parq.getDriver();
//                  String checkBoxNotTickedvalue = (String) js1.executeScript("return window.getComputedStyle(arguments[0],'::after').getPropertyValue('content');", checkBoxNotTicked);
//                  System.out.println("checkBoxNotTickedvalue is " + checkBoxNotTickedvalue);
                  
                  
                  
                  
//                    boolean text = Parq.getDriver().findElement(By.xpath("//label[contains(.,'Key Account')]/span[@class='slds-checkbox_faux'][1]")).isSelected();
//                    System.out.println(text);
                    
                    
//                    focus(css("title", "Edit Key Account"));
//                    touchJS();
//                    xxxx.sleep(3);                   
                    //WebElement toggle = Parq.getDriver().findElement(By.xpath("//span[@class='slds-checkbox slds-checkbox_standalone']/input[@name='CAP_CC_Key_Account__c']"));
                    //perform(new MouseHoverAndClickHandler(toggle));
         
                  
                    //getDriver().findElement(By.xpath("//span[@class='slds-checkbox slds-checkbox_standalone']/input[@name='CAP_CC_Key_Account__c']")).click();
                    //WebElement checkBox =  getDriver().findElement(By.xpath("//*[contains(@name,'CAP_CC_Key_Account__c')]"));
            		//((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", checkBox);
            		//checkBox.click();
            		//WebElement checkBox =  getDriver().findElement(By.xpath("//*[contains(@name,'CAP_CC_Confidential_Indicator__c')]"));
//            		xxxx.sleep(2);
//            		//focus(className("footer-button save-button"));  // Use findElement
//            		focus(css("name","SaveEdit"));
//            		touch();  
                    
                    //getDriver().findElement(By.xpath(".//*[text() = 'Key Account']/parent::*//span[@class = 'slds-checkbox_faux']")).click();
//                    WebElement toggle = Parq.getDriver().findElement(By.xpath(".//*[text() = 'Key Account']/parent::*//span[@class = 'slds-checkbox_faux']"));
//                    perform(new MouseHoverAndClickHandler(toggle));
                    
//                    focus(className("footer-button save-button"));
//                    touch();
                  
                    
                                        
//                    final String CV_MANAGER = "CV Manager";
//                    Locator CONTACT_DOCUMENT = text("Contact Documents");
//                    FasterTabs.select(FasterTabs.Type.CV_MANAGER);
//                    int count = 0;
//                    int maxReTries = 30;
//                    while (true) {
//                        getDriver().navigate().refresh();
//                        pause(5);
//                        FasterTabs.select(FasterTabs.Type.CV_MANAGER);
//                        pause(1);
//                        try {
//                            focus(CONTACT_DOCUMENT);                           
//                            traverse();
//                            present(enc("(1)"));
//                            String elementTitle =Parq.getDriver().findElement(By.xpath("//div[@class='slds-media__body slds-align-middle']//span[2]")).getAttribute("title");
//                            if(elementTitle.contains("(1)")) {
//                            	break;
//                            }
//                            
//                        } catch (Throwable ignored) {
//                        }
//
//                        if (count == maxReTries) {
//                            System.out.println(format("CV is NOT received from General CV Submission. Giving up after '%s' attempts.", maxReTries));
//                            throw new ParqException("CV is NOT received from General CV submission. Giving up after 30 attempts.");
//                        }
//
//                    }
                    
                    
//                    WebElement upload = Parq.getDriver().findElement(By.xpath("//div[@class='upload-list']"));
//                    upload.click();
//                    upload.sendKeys("C:\\Users\\ramugogurla\\git\\CustomerConnect\\CCProject\\src\\main\\resources\\CV\\CVFrench.PDF");
                    
//                    WebElement fileInput = Parq.getDriver().findElement(By.xpath("//a[@class='button browse']"));
//                    fileInput.sendKeys("C:/Users/ramugogurla/git/CustomerConnect/CCProject/src/main/resources/CV/CVFrench.PDF");
                  
                    
//                    WebElement ele = Parq.getDriver().findElement(By.xpath("//input[@type='file']"));            				
//            		LocalFileDetector detector = new LocalFileDetector();
//            		((RemoteWebElement)ele).setFileDetector(detector);
//            		String filePath = getResourcePath(applicantDetailsCountrySpecificDoc.getCvPath());            	     	            		
//            		ele.sendKeys(detector.getLocalFile(filePath).getAbsolutePath());            		
            		
            		//ele.sendKeys(detector.getLocalFile("C:/Users/ramugogurla/git/CustomerConnect/CCProject/src/main/resources/CV/CVFrench.DOCX").getAbsolutePath()); 
                    
                    //Runtime.getRuntime().exec(" C:\\Users\\ramugogurla\\git\\CustomerConnect\\CCProject\\src\\main\\resources\\CV\\CVFrench.PDF");
////                    
//                    broadBeanSubmission.jobApplicationUK_MP_PDF("AutoAPI Job ddrkgy", applicantDetailsCountrySpecificPDF);
//                    
//                    
//                    broadBeanSubmission.jobApplicationUK_MP( "jn-022022-174225", applicantDetailsCountrySpecificDoc);
//                    
//                  //######### Start action - SALESFORCE xxxx ##########
//                    //EmailCVToClient.switchToParentTab();
//                    CustomerConnectBroadBeanForm.select(LOGIN_TO_BROADBEAN);
//                    pause(5);
//                    //######### End action - SALESFORCE xxxx ##########
//
//                    //######### Start action - BROADBEAN xxxx ##########
//                    ArrayList<String> tabs = new ArrayList<String> (Parq.getDriver().getWindowHandles());
//                    Parq.getDriver().switchTo().window(tabs.get(1));
//                    xxxx.sleep(2);
//                    BroadBean.selectManageAdvert();
//                    ManageAdverts.selectJob("AutoAPI Job dlinth");
//                    Responses.selectJobResponses();
//                                  
//                    broadBeanSubmission.jobApplicationUK_MP( "jn-022022-174225", applicantDetailsCountrySpecificDoc);
//                    Browser.switchWindow(Index.WindowIndex.NEXT);
//                    JobAdvert jobAdvert = JobAdvert.create(country); // VM UPDATE
//                    JobAdvert.console(jobAdvert);
//                    xxxx.sleep(5);
//                    AdvertForm.post(jobAdvert); //fetch the Salesforce JOB REFERENCE here
                    //https://testfile--uat.lightning.force.com/lightning/r/TR1__Job__c/a1C3L000001DWySUAW/view
                    	//https://testfile--uat.lightning.force.com/lightning/r/TR1__Job__c/a1C3L000001DWxoUAG/view
//                    
                    
                    

    }

    private static void show() {
		// TODO Auto-generated method stub
		
	}

	private static URL getEndpoint(WebDriver driver) throws NoSuchFieldException, IllegalAccessException {
        // get RemoteWebDriver type
        Class remoteWebDriver = getRemoteWebDriver(driver.getClass());

        // get this instance executor > get this instance internalExecutor
        Field executorField = remoteWebDriver.getDeclaredField("executor");
        executorField.setAccessible(true);
        CommandExecutor executor = (CommandExecutor) executorField.get(driver);

        // get URL
        Field endpointField = getCommandExecutor(executor.getClass()).getDeclaredField("remoteServer");
        endpointField.setAccessible(true);

        // result
        return (URL) endpointField.get(executor);
    }

    private static Class getRemoteWebDriver(Class type) {
        // if not a remote web driver, return the type used for the call
        if (!RemoteWebDriver.class.isAssignableFrom(type)) {
            return type;
        }

        // iterate until gets the RemoteWebDriver type
        while (type != RemoteWebDriver.class) {
            type = type.getSuperclass();
        }

        // gets RemoteWebDriver to use for extracting internal information
        return type;
    }

    private static Class getCommandExecutor(Class type) {
        // if not a remote web driver, return the type used for the call
        if (!HttpCommandExecutor.class.isAssignableFrom(type)) {
            return type;
        }

        // iterate until gets the RemoteWebDriver type
        while (type != HttpCommandExecutor.class) {
            type = type.getSuperclass();
        }

        // gets RemoteWebDriver to use for extracting internal information
        return type;
    }
    public static RemoteWebDriver createDriverFromSession(final SessionId sessionId, URL command_executor){
        CommandExecutor executor = new HttpCommandExecutor(command_executor) {

            @Override
            public Response execute(Command command) throws IOException {
                Response response = null;
                if (command.getName() == "newSession") {
                    response = new Response();
                    response.setSessionId(sessionId.toString());
                    response.setStatus(0);
                    response.setValue(Collections.<String, String>emptyMap());

                    try {
                        Field commandCodec = null;
                        commandCodec = this.getClass().getSuperclass().getDeclaredField("commandCodec");
                        commandCodec.setAccessible(true);
                        commandCodec.set(this, new W3CHttpCommandCodec());

                        Field responseCodec = null;
                        responseCodec = this.getClass().getSuperclass().getDeclaredField("responseCodec");
                        responseCodec.setAccessible(true);
                        responseCodec.set(this, new W3CHttpResponseCodec());
                    } catch (NoSuchFieldException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                } else {
                    response = super.execute(command);
                }
                return response;
            }
        };

        return new RemoteWebDriver(executor, new DesiredCapabilities());
    }
}

